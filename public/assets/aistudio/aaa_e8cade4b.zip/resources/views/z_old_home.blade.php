<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Live Streaming Rankings - Real-time Gaming Stats</title>
    <meta name="description" content="Real-time ranking of the hottest live streams across all gaming platforms. See live viewer counts and trending channels.">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --background: hsl(240, 10%, 3.9%);
            --foreground: hsl(0, 0%, 98%);
            --primary: hsl(263, 70%, 50.4%);
            --secondary: hsl(240, 3.7%, 15.9%);
            --muted-foreground: hsl(240, 5%, 64.9%);
            --border: hsl(240, 3.7%, 15.9%);
            --live-indicator: hsl(0, 84%, 60%);
            --viewer-count: hsl(142, 76%, 36%);
            --rank-gold: hsl(45, 93%, 58%);
            --rank-silver: hsl(0, 0%, 75%);
            --rank-bronze: hsl(30, 67%, 44%);
        }

        body {
            background: linear-gradient(180deg, 
                hsl(240, 10%, 3.9%) 0%,
                hsl(250, 15%, 8%) 40%,
                hsl(240, 10%, 3.9%) 100%
            );
            min-height: 100vh;
            color: var(--foreground);
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
            line-height: 1.6;
            overflow-x: hidden;
        }

        .hero {
            position: relative;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, var(--primary), hsl(290, 70%, 45%));
            overflow: hidden;
        }

        .hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: 
                radial-gradient(circle at 20% 80%, hsla(263, 70%, 50%, 0.3) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, hsla(290, 70%, 45%, 0.3) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, hsla(0, 84%, 60%, 0.2) 0%, transparent 50%);
            animation: heroGlow 8s ease-in-out infinite alternate;
        }

        @keyframes heroGlow {
            0% { opacity: 0.8; transform: scale(1); }
            100% { opacity: 1; transform: scale(1.05); }
        }

        .hero-content {
            position: relative;
            z-index: 10;
            text-align: center;
            max-width: 1200px;
            padding: 2rem;
        }

        .hero-title {
            font-size: clamp(3rem, 8vw, 7rem);
            font-weight: 900;
            margin-bottom: 1.5rem;
            background: linear-gradient(135deg, #fff, #f0f0f0);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            text-shadow: 0 0 30px rgba(255, 255, 255, 0.3);
            animation: heroTitle 2s ease-out;
        }

        @keyframes heroTitle {
            0% { opacity: 0; transform: translateY(50px) scale(0.9); }
            100% { opacity: 1; transform: translateY(0) scale(1); }
        }

        .hero-subtitle {
            font-size: clamp(1.2rem, 3vw, 2rem);
            margin-bottom: 3rem;
            color: rgba(255, 255, 255, 0.9);
            font-weight: 300;
            animation: heroSubtitle 2s ease-out 0.3s both;
        }

        @keyframes heroSubtitle {
            0% { opacity: 0; transform: translateY(30px); }
            100% { opacity: 1; transform: translateY(0); }
        }

        .hero-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 2rem;
            margin-top: 3rem;
            animation: heroStats 2s ease-out 0.6s both;
        }

        @keyframes heroStats {
            0% { opacity: 0; transform: translateY(30px); }
            100% { opacity: 1; transform: translateY(0); }
        }

        .hero-stat {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 16px;
            padding: 2rem;
            transition: all 0.3s ease;
        }

        .hero-stat:hover {
            transform: translateY(-5px);
            background: rgba(255, 255, 255, 0.15);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
        }

        .hero-stat-number {
            font-size: 2.5rem;
            font-weight: 900;
            color: var(--live-indicator);
            margin-bottom: 0.5rem;
        }

        .hero-stat-label {
            font-size: 1rem;
            color: rgba(255, 255, 255, 0.8);
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .scroll-indicator {
            position: absolute;
            bottom: 2rem;
            left: 50%;
            transform: translateX(-50%);
            animation: bounce 2s infinite;
        }

        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% { transform: translateX(-50%) translateY(0); }
            40% { transform: translateX(-50%) translateY(-10px); }
            60% { transform: translateX(-50%) translateY(-5px); }
        }

        .scroll-arrow {
            width: 30px;
            height: 30px;
            border: 2px solid rgba(255, 255, 255, 0.7);
            border-top: none;
            border-left: none;
            transform: rotate(45deg);
        }

        .main-content {
            padding: 4rem 2rem;
            max-width: 1200px;
            margin: 0 auto;
        }

        .section-title {
            font-size: 2.5rem;
            font-weight: 700;
            text-align: center;
            margin-bottom: 3rem;
            background: linear-gradient(135deg, var(--primary), var(--live-indicator));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .ranking-card {
            background: linear-gradient(135deg, rgba(240, 3.7%, 15.9%, 0.8), rgba(240, 10%, 3.9%, 0.9));
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 2rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 8px 32px rgba(240, 10%, 3.9%, 0.8);
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 2rem;
        }

        .ranking-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 0 20px rgba(0, 84%, 60%, 0.3);
            border-color: var(--primary);
        }

        .rank-number {
            font-size: 2.5rem;
            font-weight: 900;
            min-width: 80px;
        }

        .rank-1 { color: var(--rank-gold); }
        .rank-2 { color: var(--rank-silver); }
        .rank-3 { color: var(--rank-bronze); }
        .rank-other { color: var(--muted-foreground); }

        .channel-logo {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 4px solid rgba(263, 70%, 50.4%, 0.3);
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .ranking-card:hover .channel-logo {
            border-color: rgba(263, 70%, 50.4%, 0.6);
        }

        .channel-logo img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .live-badge {
            position: absolute;
            top: -4px;
            right: -4px;
            background: linear-gradient(90deg, var(--live-indicator), hsl(15, 90%, 55%));
            color: white;
            font-size: 0.7rem;
            font-weight: 700;
            padding: 4px 8px;
            border-radius: 12px;
            animation: livePulse 2s infinite;
        }

        @keyframes livePulse {
            0%, 100% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.8; transform: scale(1.05); }
        }

        .channel-info {
            flex: 1;
            min-width: 0;
        }

        .channel-name {
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            transition: color 0.3s ease;
        }

        .ranking-card:hover .channel-name {
            color: var(--primary);
        }

        .video-title {
            color: var(--muted-foreground);
            font-size: 1.1rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .viewer-count {
            text-align: right;
        }

        .viewer-label {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 0.5rem;
            font-size: 0.9rem;
            color: var(--muted-foreground);
            margin-bottom: 0.5rem;
        }

        .live-dot {
            width: 12px;
            height: 12px;
            background: var(--live-indicator);
            border-radius: 50%;
            animation: livePulse 2s infinite;
        }

        .viewer-number {
            font-size: 2rem;
            font-weight: 900;
            color: var(--viewer-count);
        }

        @media (max-width: 768px) {
            .ranking-card {
                flex-direction: column;
                text-align: center;
                gap: 1rem;
            }

            .rank-number {
                min-width: auto;
            }

            .channel-info {
                order: 1;
            }

            .viewer-count {
                text-align: center;
                order: 2;
            }

            .video-title {
                white-space: normal;
                display: -webkit-box;
                -webkit-line-clamp: 2;
                -webkit-box-orient: vertical;
                overflow: hidden;
                line-height: 1.4;
            }
        }
    </style>
</head>
<body>
    <!--header class="hero">
        <div class="hero-content">
            <h1 class="hero-title">LIVE RANKINGS</h1>
            <p class="hero-subtitle">Real-time streaming leaderboard across all gaming platforms</p>
            
            <div class="hero-stats">
                <div class="hero-stat">
                    <div class="hero-stat-number">8</div>
                    <div class="hero-stat-label">Live Channels</div>
                </div>
                <div class="hero-stat">
                    <div class="hero-stat-number">189K</div>
                    <div class="hero-stat-label">Total Viewers</div>
                </div>
                <div class="hero-stat">
                    <div class="hero-stat-number">100%</div>
                    <div class="hero-stat-label">Uptime</div>
                </div>
            </div>
        </div>
        
        <div class="scroll-indicator">
            <div class="scroll-arrow"></div>
        </div>
    </header-->

    <main class="main-content">
        <h2 class="section-title">Top Live Streams</h2>
        @foreach ($streams as $stream)
        <div class="ranking-card">
            <div class="rank-number rank-1">#{{ $loop->index + 1 }}</div>
            <div class="channel-logo">
                <img src="https://yt3.ggpht.com/ytc/{{ $stream->channel_id }}=s88-c-k-c0x00ffffff-no-rj" alt="GamePro Studios logo">
                <div class="live-badge">LIVE</div>
            </div>
            <div class="channel-info">
                <h3 class="channel-name">{{ $stream->channel_name }} {{ $stream->scrape_date }}</h3>
                <p class="video-title"><a href="https://www.youtube.com/watch?v={{ $stream->video_id }}">{{ $stream->video_title }}</a></p>
            </div>
            <div class="viewer-count">
                <div class="viewer-label">
                    <div class="live-dot"></div>
                    Live Viewers
                </div>
                <div class="viewer-number">{{ $stream->concurrent_viewers }}</div>
            </div>
        </div>
        @endforeach

    </main>
</body>
</html>