<!DOCTYPE html><html lang="en">
  <head>
    @if($_SERVER["REMOTE_ADDR"] != "::1")
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-DG4Y02M27H"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
      gtag('config', 'G-DG4Y02M27H');
    </script>
    @endif
    <meta charset="UTF-8">
    <link rel="icon" type="image/svg+xml" href="{{ asset('img/logo.jpg') }}">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Ranking en vivo de los streaming más vistos de Argentina">
    <meta name="keywords" content="streaming, stream, usuarios, métricas, analytics, @foreach ($streams as $stream){{ $stream->channel_name }}, @endforeach">
    <meta property="og:image" content="https://streamingargy.thepodcastblog.com/featured.png">
    <title>Streaming Argy</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
      tailwind.config = {
        theme: {
          extend: {
            colors: {
              primary: '#3B82F6',
              secondary: '#14B8A6',
              accent: '#F97316',
              success: '#10B981',
              warning: '#F59E0B',
              error: '#EF4444'
            }
          }
        }
      }

    </script>
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
    <!--script type="module" crossorigin="" src="/assets/index--SwiM7HS.js"></script-->
    <link rel="stylesheet" crossorigin="" href="{{ asset('css/index-Ct_hi4gO2.css') }}">
  <!--script async="" src="https://bolt.new/badge.js?s=744581f4-b1b2-4930-977d-952c6b953a15"></script>
  <style>*, ::before, ::after{--tw-border-spacing-x:0;--tw-border-spacing-y:0;--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness:proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:rgb(59 130 246 / 0.5);--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000;--tw-shadow-colored:0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }::backdrop{--tw-border-spacing-x:0;--tw-border-spacing-y:0;--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness:proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:rgb(59 130 246 / 0.5);--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000;--tw-shadow-colored:0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }/* ! tailwindcss v3.4.17 | MIT License | https://tailwindcss.com */*,::after,::before{box-sizing:border-box;border-width:0;border-style:solid;border-color:#e5e7eb}::after,::before{--tw-content:''}:host,html{line-height:1.5;-webkit-text-size-adjust:100%;-moz-tab-size:4;tab-size:4;font-family:ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";font-feature-settings:normal;font-variation-settings:normal;-webkit-tap-highlight-color:transparent}body{margin:0;line-height:inherit}hr{height:0;color:inherit;border-top-width:1px}abbr:where([title]){-webkit-text-decoration:underline dotted;text-decoration:underline dotted}h1,h2,h3,h4,h5,h6{font-size:inherit;font-weight:inherit}a{color:inherit;text-decoration:inherit}b,strong{font-weight:bolder}code,kbd,pre,samp{font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;font-feature-settings:normal;font-variation-settings:normal;font-size:1em}small{font-size:80%}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}sub{bottom:-.25em}sup{top:-.5em}table{text-indent:0;border-color:inherit;border-collapse:collapse}button,input,optgroup,select,textarea{font-family:inherit;font-feature-settings:inherit;font-variation-settings:inherit;font-size:100%;font-weight:inherit;line-height:inherit;letter-spacing:inherit;color:inherit;margin:0;padding:0}button,select{text-transform:none}button,input:where([type=button]),input:where([type=reset]),input:where([type=submit]){-webkit-appearance:button;background-color:transparent;background-image:none}:-moz-focusring{outline:auto}:-moz-ui-invalid{box-shadow:none}progress{vertical-align:baseline}::-webkit-inner-spin-button,::-webkit-outer-spin-button{height:auto}[type=search]{-webkit-appearance:textfield;outline-offset:-2px}::-webkit-search-decoration{-webkit-appearance:none}::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}summary{display:list-item}blockquote,dd,dl,figure,h1,h2,h3,h4,h5,h6,hr,p,pre{margin:0}fieldset{margin:0;padding:0}legend{padding:0}menu,ol,ul{list-style:none;margin:0;padding:0}dialog{padding:0}textarea{resize:vertical}input::placeholder,textarea::placeholder{opacity:1;color:#9ca3af}[role=button],button{cursor:pointer}:disabled{cursor:default}audio,canvas,embed,iframe,img,object,svg,video{display:block;vertical-align:middle}img,video{max-width:100%;height:auto}[hidden]:where(:not([hidden=until-found])){display:none}.mx-auto{margin-left:auto;margin-right:auto}.mb-1{margin-bottom:0.25rem}.mb-2{margin-bottom:0.5rem}.mb-4{margin-bottom:1rem}.mb-6{margin-bottom:1.5rem}.mb-8{margin-bottom:2rem}.mt-1{margin-top:0.25rem}.mt-12{margin-top:3rem}.mt-2{margin-top:0.5rem}.flex{display:flex}.grid{display:grid}.h-10{height:2.5rem}.h-12{height:3rem}.h-16{height:4rem}.h-2{height:0.5rem}.min-h-screen{min-height:100vh}.w-10{width:2.5rem}.w-12{width:3rem}.w-16{width:4rem}.w-2{width:0.5rem}.min-w-0{min-width:0px}.max-w-2xl{max-width:42rem}.max-w-7xl{max-width:80rem}.flex-1{flex:1 1 0%}.flex-shrink-0{flex-shrink:0}@keyframes pulse{50%{opacity:.5}}.animate-pulse{animation:pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite}.grid-cols-1{grid-template-columns:repeat(1, minmax(0, 1fr))}.flex-col{flex-direction:column}.flex-wrap{flex-wrap:wrap}.items-center{align-items:center}.justify-center{justify-content:center}.justify-between{justify-content:space-between}.gap-2{gap:0.5rem}.gap-4{gap:1rem}.gap-6{gap:1.5rem}.space-x-1 > :not([hidden]) ~ :not([hidden]){--tw-space-x-reverse:0;margin-right:calc(0.25rem * var(--tw-space-x-reverse));margin-left:calc(0.25rem * calc(1 - var(--tw-space-x-reverse)))}.space-x-2 > :not([hidden]) ~ :not([hidden]){--tw-space-x-reverse:0;margin-right:calc(0.5rem * var(--tw-space-x-reverse));margin-left:calc(0.5rem * calc(1 - var(--tw-space-x-reverse)))}.space-x-3 > :not([hidden]) ~ :not([hidden]){--tw-space-x-reverse:0;margin-right:calc(0.75rem * var(--tw-space-x-reverse));margin-left:calc(0.75rem * calc(1 - var(--tw-space-x-reverse)))}.space-x-4 > :not([hidden]) ~ :not([hidden]){--tw-space-x-reverse:0;margin-right:calc(1rem * var(--tw-space-x-reverse));margin-left:calc(1rem * calc(1 - var(--tw-space-x-reverse)))}.space-x-6 > :not([hidden]) ~ :not([hidden]){--tw-space-x-reverse:0;margin-right:calc(1.5rem * var(--tw-space-x-reverse));margin-left:calc(1.5rem * calc(1 - var(--tw-space-x-reverse)))}.space-y-4 > :not([hidden]) ~ :not([hidden]){--tw-space-y-reverse:0;margin-top:calc(1rem * calc(1 - var(--tw-space-y-reverse)));margin-bottom:calc(1rem * var(--tw-space-y-reverse))}.overflow-hidden{overflow:hidden}.truncate{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.rounded-full{border-radius:9999px}.rounded-lg{border-radius:0.5rem}.rounded-xl{border-radius:0.75rem}.border{border-width:1px}.border-2{border-width:2px}.border-b{border-bottom-width:1px}.border-gray-100{--tw-border-opacity:1;border-color:rgb(243 244 246 / var(--tw-border-opacity, 1))}.border-gray-200{--tw-border-opacity:1;border-color:rgb(229 231 235 / var(--tw-border-opacity, 1))}.bg-gray-50{--tw-bg-opacity:1;background-color:rgb(249 250 251 / var(--tw-bg-opacity, 1))}.bg-blue-100{--tw-bg-opacity:1;background-color:rgb(219 234 254 / var(--tw-bg-opacity, 1))}.bg-gray-100{--tw-bg-opacity:1;background-color:rgb(243 244 246 / var(--tw-bg-opacity, 1))}.bg-green-100{--tw-bg-opacity:1;background-color:rgb(220 252 231 / var(--tw-bg-opacity, 1))}.bg-green-500{--tw-bg-opacity:1;background-color:rgb(34 197 94 / var(--tw-bg-opacity, 1))}.bg-indigo-100{--tw-bg-opacity:1;background-color:rgb(224 231 255 / var(--tw-bg-opacity, 1))}.bg-orange-100{--tw-bg-opacity:1;background-color:rgb(255 237 213 / var(--tw-bg-opacity, 1))}.bg-pink-100{--tw-bg-opacity:1;background-color:rgb(252 231 243 / var(--tw-bg-opacity, 1))}.bg-primary{--tw-bg-opacity:1;background-color:rgb(59 130 246 / var(--tw-bg-opacity, 1))}.bg-purple-100{--tw-bg-opacity:1;background-color:rgb(243 232 255 / var(--tw-bg-opacity, 1))}.bg-red-100{--tw-bg-opacity:1;background-color:rgb(254 226 226 / var(--tw-bg-opacity, 1))}.bg-red-500{--tw-bg-opacity:1;background-color:rgb(239 68 68 / var(--tw-bg-opacity, 1))}.bg-white{--tw-bg-opacity:1;background-color:rgb(255 255 255 / var(--tw-bg-opacity, 1))}.bg-yellow-100{--tw-bg-opacity:1;background-color:rgb(254 249 195 / var(--tw-bg-opacity, 1))}.bg-gradient-to-br{background-image:linear-gradient(to bottom right, var(--tw-gradient-stops))}.bg-gradient-to-r{background-image:linear-gradient(to right, var(--tw-gradient-stops))}.from-gray-300{--tw-gradient-from:#d1d5db var(--tw-gradient-from-position);--tw-gradient-to:rgb(209 213 219 / 0) var(--tw-gradient-to-position);--tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to)}.from-gray-50{--tw-gradient-from:#f9fafb var(--tw-gradient-from-position);--tw-gradient-to:rgb(249 250 251 / 0) var(--tw-gradient-to-position);--tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to)}.from-orange-400{--tw-gradient-from:#fb923c var(--tw-gradient-from-position);--tw-gradient-to:rgb(251 146 60 / 0) var(--tw-gradient-to-position);--tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to)}.from-primary{--tw-gradient-from:#3B82F6 var(--tw-gradient-from-position);--tw-gradient-to:rgb(59 130 246 / 0) var(--tw-gradient-to-position);--tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to)}.from-yellow-400{--tw-gradient-from:#facc15 var(--tw-gradient-from-position);--tw-gradient-to:rgb(250 204 21 / 0) var(--tw-gradient-to-position);--tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to)}.to-gray-100{--tw-gradient-to:#f3f4f6 
  var(--tw-gradient-to-position)}.to-gray-400{--tw-gradient-to:#9ca3af var(--tw-gradient-to-position)}.to-orange-600{--tw-gradient-to:#ea580c var(--tw-gradient-to-position)}.to-secondary{--tw-gradient-to:#14B8A6 var(--tw-gradient-to-position)}.to-yellow-600{--tw-gradient-to:#ca8a04 var(--tw-gradient-to-position)}.bg-clip-text{-webkit-background-clip:text;background-clip:text}.object-cover{object-fit:cover}.p-6{padding:1.5rem}.px-2{padding-left:0.5rem;padding-right:0.5rem}.px-4{padding-left:1rem;padding-right:1rem}.py-1{padding-top:0.25rem;padding-bottom:0.25rem}.py-2{padding-top:0.5rem;padding-bottom:0.5rem}.py-8{padding-top:2rem;padding-bottom:2rem}.text-center{text-align:center}.text-2xl{font-size:1.5rem;line-height:2rem}.text-3xl{font-size:1.875rem;line-height:2.25rem}.text-4xl{font-size:2.25rem;line-height:2.5rem}.text-lg{font-size:1.125rem;line-height:1.75rem}.text-sm{font-size:0.875rem;line-height:1.25rem}.text-xl{font-size:1.25rem;line-height:1.75rem}.text-xs{font-size:0.75rem;line-height:1rem}.font-bold{font-weight:700}.font-medium{font-weight:500}.font-semibold{font-weight:600}.uppercase{text-transform:uppercase}.tracking-wider{letter-spacing:0.05em}.text-accent{--tw-text-opacity:1;color:rgb(249 115 22 / var(--tw-text-opacity, 1))}.text-blue-800{--tw-text-opacity:1;color:rgb(30 64 175 / var(--tw-text-opacity, 1))}.text-gray-500{--tw-text-opacity:1;color:rgb(107 114 128 / var(--tw-text-opacity, 1))}.text-gray-600{--tw-text-opacity:1;color:rgb(75 85 99 / var(--tw-text-opacity, 1))}.text-gray-700{--tw-text-opacity:1;color:rgb(55 65 81 / var(--tw-text-opacity, 1))}.text-gray-800{--tw-text-opacity:1;color:rgb(31 41 55 / var(--tw-text-opacity, 1))}.text-gray-900{--tw-text-opacity:1;color:rgb(17 24 39 / var(--tw-text-opacity, 1))}.text-green-800{--tw-text-opacity:1;color:rgb(22 101 52 / var(--tw-text-opacity, 1))}.text-indigo-800{--tw-text-opacity:1;color:rgb(55 48 163 / var(--tw-text-opacity, 1))}.text-orange-800{--tw-text-opacity:1;color:rgb(154 52 18 / var(--tw-text-opacity, 1))}.text-pink-800{--tw-text-opacity:1;color:rgb(157 23 77 / var(--tw-text-opacity, 1))}.text-primary{--tw-text-opacity:1;color:rgb(59 130 246 / var(--tw-text-opacity, 1))}.text-purple-600{--tw-text-opacity:1;color:rgb(147 51 234 / var(--tw-text-opacity, 1))}.text-purple-800{--tw-text-opacity:1;color:rgb(107 33 168 / var(--tw-text-opacity, 1))}.text-red-500{--tw-text-opacity:1;color:rgb(239 68 68 / var(--tw-text-opacity, 1))}.text-red-800{--tw-text-opacity:1;color:rgb(153 27 27 / var(--tw-text-opacity, 1))}.text-secondary{--tw-text-opacity:1;color:rgb(20 184 166 / var(--tw-text-opacity, 1))}.text-transparent{color:transparent}.text-white{--tw-text-opacity:1;color:rgb(255 255 255 / var(--tw-text-opacity, 1))}.text-yellow-800{--tw-text-opacity:1;color:rgb(133 77 14 / var(--tw-text-opacity, 1))}.shadow-md{--tw-shadow:0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);--tw-shadow-colored:0 4px 6px -1px var(--tw-shadow-color), 0 2px 4px -2px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)}.shadow-sm{--tw-shadow:0 1px 2px 0 rgb(0 0 0 / 0.05);--tw-shadow-colored:0 1px 2px 0 var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)}.transition-all{transition-property:all;transition-timing-function:cubic-bezier(0.4, 0, 0.2, 1);transition-duration:150ms}.transition-colors{transition-property:color, background-color, border-color, fill, stroke, -webkit-text-decoration-color;transition-property:color, background-color, border-color, text-decoration-color, fill, stroke;transition-property:color, background-color, border-color, text-decoration-color, fill, stroke, -webkit-text-decoration-color;transition-timing-function:cubic-bezier(0.4, 0, 0.2, 1);transition-duration:150ms}.duration-200{transition-duration:200ms}.duration-300{transition-duration:300ms}.hover\:bg-gray-50:hover{--tw-bg-opacity:1;background-color:rgb(249 250 251 / var(--tw-bg-opacity, 1))}.hover\:shadow-lg:hover{--tw-shadow:0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);--tw-shadow-colored:0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)}.focus\:outline-none:focus{outline:2px solid transparent;outline-offset:2px}.focus\:ring-2:focus{--tw-ring-offset-shadow:var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);--tw-ring-shadow:var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);box-shadow:var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000)}.focus\:ring-primary:focus{--tw-ring-opacity:1;--tw-ring-color:rgb(59 130 246 / var(--tw-ring-opacity, 1))}.focus\:ring-offset-2:focus{--tw-ring-offset-width:2px}.group:hover .group-hover\:border-primary{--tw-border-opacity:1;border-color:rgb(59 130 246 / var(--tw-border-opacity, 1))}@media (min-width: 640px){.sm\:flex-row{flex-direction:row}.sm\:items-center{align-items:center}.sm\:justify-between{justify-content:space-between}.sm\:px-6{padding-left:1.5rem;padding-right:1.5rem}}@media (min-width: 768px){.md\:grid-cols-4{grid-template-columns:repeat(4, minmax(0, 1fr))}}@media (min-width: 1024px){.lg\:px-8{padding-left:2rem;padding-right:2rem}}
  </style-->
  <style>
        .chart-container {
           
            max-width: 100%;
        }
        canvas {
            max-width: 100%;
        }
    </style>
  </head>
  <body class="bg-gray-50">
    <div id="app">
  <div class="min-h-screen bg-gradient-to-br from-white via-gray-50 to-gray-100 relative overflow-hidden">

    @include('floating-crap')


      <div class="relative z-10">
    <!-- Header -->
    @include('header')

    <!-- Main Content -->
    <main class="@if(request()->has('dev')) max-w-3xl @else max-w-5xl @endif mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <!-- Hero Section -->
      <!--div class="text-center mb-8">
        <h2 class="text-4xl font-bold text-gray-900 mb-4">
          <span class="bg-gradient-to-r from-sky-500 via-sky-300 to-sky-500  bg-clip-text text-transparent">
          <a href="{{ route('home') }}" class="">Streaming Argy</a>
          </span>
        </h2>
        <p class="text-lg text-gray-600 max-w-2xl mx-auto">
          Ranking en vivo de los streamings más vistos de Argentina
        </p>
      </div-->

      <!-- Stats Overview -->
      <!--div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div class="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div class="text-center">
            <div class="text-3xl font-bold text-primary mb-2">172.8K</div>
            <div class="text-gray-600">Total Live Viewers</div>
          </div>
        </div>
        <div class="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div class="text-center">
            <div class="text-3xl font-bold text-secondary mb-2">8</div>
            <div class="text-gray-600">Active Streams</div>
          </div>
        </div>
        <div class="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div class="text-center">
            <div class="text-3xl font-bold text-accent mb-2">42.1K</div>
            <div class="text-gray-600">Total Likes</div>
          </div>
        </div>
        <div class="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div class="text-center">
            <div class="text-3xl font-bold text-purple-600 mb-2">39.6K</div>
            <div class="text-gray-600">Total Comments</div>
          </div>
        </div>
      </div-->

      <!-- Filter Section -->
      <!--div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6 mb-8">
        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h3 class="text-lg font-semibold text-gray-900 mb-1">Categorías</h3>
            <p class="text-sm text-gray-600">Seleccioná una categoría</p>
          </div>
          <div class="flex flex-wrap gap-2">
            
            <a href="{{ url()->current() }}"  class="@if(!request()->has('tag')) bg-primary text-white @else bg-white text-gray-700 hover:bg-gray-50 @endif border border-gray-200 px-4 py-2 rounded-lg font-medium text-sm transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2">
              Todos
            </a>
          
            <a href="{{ url()->current() }}/?tag=stream" class="@if(request()->query('tag') == 'stream') bg-primary text-white @else bg-white text-gray-700 hover:bg-gray-50 @endif  border border-gray-200 px-4 py-2 rounded-lg font-medium text-sm transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2">
              Streaming
            </a>
          
            <a href="{{ url()->current() }}/?tag=tv" class="@if(request()->query('tag') == 'tv') bg-primary text-white @else bg-white text-gray-700 hover:bg-gray-50 @endif border border-gray-200 px-4 py-2 rounded-lg font-medium text-sm transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2">
              TV
            </a>
          
            <a href="{{ url()->current() }}/?tag=noticias" class="@if(request()->query('tag') == 'noticias') bg-primary text-white @else bg-white text-gray-700 hover:bg-gray-50 @endif border border-gray-200 px-4 py-2 rounded-lg font-medium text-sm transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2">
              Noticias
            </a>
          
            <a href="{{ url()->current() }}/?tag=radio" class="@if(request()->query('tag') == 'radio') bg-primary text-white @else bg-white text-gray-700 hover:bg-gray-50 @endif border border-gray-200 px-4 py-2 rounded-lg font-medium text-sm transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2">
              Radio
            </a>

            <a href="{{ url()->current() }}/?tag=política" class="@if(request()->query('tag') == 'política') bg-primary text-white @else bg-white text-gray-700 hover:bg-gray-50 @endif border border-gray-200 px-4 py-2 rounded-lg font-medium text-sm transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2">
              Política
            </a>

            <a href="{{ url()->current() }}/?tag=deportes" class="@if(request()->query('tag') == 'deportes') bg-primary text-white @else bg-white text-gray-700 hover:bg-gray-50 @endif border border-gray-200 px-4 py-2 rounded-lg font-medium text-sm transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2">
              Deportes
            </a>    
          </div>
        </div>
      </div-->

      <div class="space-y-4">

        <div class="bg-white rounded-xl shadow-sm hover:shadow-lg transition-all duration-300 border border-gray-100 overflow-hidden group">
          <div class="p-4 md:p-6">
            <!-- Desktop Layout -->
            <div class="hidden sm:flex items-center space-x-4">
              <div class="flex items-center space-x-4 flex-1 min-w-0">
                  <a href="{{ route('channel', $channel->channel_id) }}">
                  <img src="{{ $channel->thumb }}" alt="{{ $channel->channel }}" class="w-16 h-16 rounded-full object-cover border-2 border-gray-200 group-hover:border-primary transition-colors">
                  </a>
                  <div class="flex-1 min-w-0">
                  <h3 class="font-semibold text-gray-900 truncate">{{ $channel->channel_name }} 
                    ({{ $channel->subs >= 1000000 ? number_format($channel->subs/1000000,1,".",",") . "M" : number_format($channel->subs/1000,0,".",",") . "k" }})             
                  </h3>  
                
                  <p class="text-sm text-gray-600 truncate mt-1">{{ $channel->description }}</p>
                  <div class="mt-2">
                      <span class="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium">{{ $channel->channel }}</span>
                      <!--span class="bg-purple-100 text-purple-800 px-2 py-1 rounded-full text-xs font-medium">
                        <a href="{{ route('channel', $channel->channel_id) }}">Métricas</a>
                      </span-->
                  </div>
                  </div>
              </div>
            </div>
            
            <!-- Mobile Layout -->
            <div class="sm:hidden">
              <div class="flex items-start space-x-3">
                <!-- Channel Thumbnail -->
                <img src="{{ $channel->thumb }}" alt="{{ $channel->channel }}" class="w-12 h-12 rounded-full object-cover border-2 border-gray-200 flex-shrink-0">
                
                <!-- Content -->
                <div class="flex-1 min-w-0">
                  <h3 class="font-semibold text-gray-900 text-sm leading-tight">{{ $channel->channel_name }}  ({{ $channel->subs >= 1000000 ? number_format($channel->subs/1000000,1,".",",") . "M" : number_format($channel->subs/1000,0,".",",") . "k" }})             </h3>
                  <p class="text-xs text-gray-600 mt-1 line-clamp-2">{{ $channel->description }}</p>  
                </div>
              </div>
            </div>
          </div>
        </div>
  <hr style="margin-top: 20px; margin-bottom: 20px;">
       <div class="flex items-center justify-between mb-6">
          <h3 class="text-2xl font-bold text-gray-900">
           🔥 Heatmap - Usuarios promedio conectados 
          </h3>
        </div>

        <div class="bg-white rounded-xl shadow-sm hover:shadow-lg transition-all duration-300 border border-gray-100 overflow-hidden group">
          <div class="p-8 chart-container">
              <!--div class="w-full overflow-x-auto block md:hidden">
                mob
              <table id="heatmap-table-mob" class="min-w-full border-collapse">
                <thead class="bg-gray-600 text-white">
                  <tr> 
                    <td class="px-4 py-3 text-center text-sm font-semibold">Hora</td>
                    <td class="px-4 py-3 text-center">L</td>
                    <td class="px-4 py-3 text-center">M</td>
                    <td class="px-4 py-3 text-center">X</td>
                    <td class="px-4 py-3 text-center">J</td>
                    <td class="px-4 py-3 text-center">V</td>
                    <td class="px-4 py-3 text-center">S</td>
                    <td class="px-4 py-3 text-center">D</td>
                  </tr>
                </thead>
                <tbody class="divide-y divide-gray-200 text-sm text-gray-700">
                  @foreach ($hour_day_data as $hd)
                  <tr class="bg-gray-100"> 
                    <td class="px-4 py-2 font-medium text-center">{{ $hd->hour }}</td>
                    <td class="px-4 py-2 font-medium text-center">{{ $hd->mon_viewers > 0 ? number_format($hd->mon_viewers,0,",",".") : '-' }}</td>
                    <td class="px-4 py-2 font-medium text-center">{{ $hd->tue_viewers > 0 ? number_format($hd->tue_viewers,0,",",".") : '-' }}</td>
                    <td class="px-4 py-2 font-medium text-center">{{ $hd->wed_viewers > 0 ? number_format($hd->wed_viewers,0,",",".") : '-' }}</td>
                    <td class="px-4 py-2 font-medium text-center">{{ $hd->thu_viewers > 0 ? number_format($hd->thu_viewers,0,",",".") : '-' }}</td>
                    <td class="px-4 py-2 font-medium text-center">{{ $hd->fri_viewers > 0 ? number_format($hd->fri_viewers,0,",",".") : '-' }}</td>
                    <td class="px-4 py-2 font-medium text-center">{{ $hd->sat_viewers > 0 ? number_format($hd->sat_viewers,0,",",".") : '-' }}</td>
                    <td class="px-4 py-2 font-medium text-center">{{ $hd->sun_viewers > 0 ? number_format($hd->sun_viewers,0,",",".") : '-' }}</td>
                  </tr>
                  @endforeach
                </tbody>
              </table>
              </div-->

              <div class="w-full overflow-x-auto block "> <!-- hidden md:block -->
                
                <table id="heatmap-table" class="min-w-full border-collapse">
                <thead class="bg-gray-600 text-white">
                  <tr> 
                    <td class="px-4 py-3 text-center text-sm font-semibold">Hora</td>
                    <td class="px-4 py-3 text-center">Lunes</td>
                    <td class="px-4 py-3 text-center">Martes</td>
                    <td class="px-4 py-3 text-center">Miércoles</td>
                    <td class="px-4 py-3 text-center">Jueves</td>
                    <td class="px-4 py-3 text-center">Viernes</td>
                    <td class="px-4 py-3 text-center">Sábado</td>
                    <td class="px-4 py-3 text-center">Domingo</td>
                  </tr>
                </thead>
                <tbody class="divide-y divide-gray-200 text-sm text-gray-700">
                  @foreach ($hour_day_data as $hd)
                  <tr class="bg-gray-100"> 
                    <td class="px-4 py-2 font-medium text-center">{{ $hd->hour }}</td>
                    <td class="px-4 py-2 font-medium text-center">{{ $hd->mon_viewers > 0 ? number_format($hd->mon_viewers,0,",",".") : '-' }}</td>
                    <td class="px-4 py-2 font-medium text-center">{{ $hd->tue_viewers > 0 ? number_format($hd->tue_viewers,0,",",".") : '-' }}</td>
                    <td class="px-4 py-2 font-medium text-center">{{ $hd->wed_viewers > 0 ? number_format($hd->wed_viewers,0,",",".") : '-' }}</td>
                    <td class="px-4 py-2 font-medium text-center">{{ $hd->thu_viewers > 0 ? number_format($hd->thu_viewers,0,",",".") : '-' }}</td>
                    <td class="px-4 py-2 font-medium text-center">{{ $hd->fri_viewers > 0 ? number_format($hd->fri_viewers,0,",",".") : '-' }}</td>
                    <td class="px-4 py-2 font-medium text-center">{{ $hd->sat_viewers > 0 ? number_format($hd->sat_viewers,0,",",".") : '-' }}</td>
                    <td class="px-4 py-2 font-medium text-center">{{ $hd->sun_viewers > 0 ? number_format($hd->sun_viewers,0,",",".") : '-' }}</td>
                  </tr>
                  @endforeach
                </tbody>
                </table>
              </div>
          </div>
        </div>

         <script>



              function heatme(table) {
                // 🎨 Auto-color cells from green → yellow → red based on min/max
                //const table = document.getElementById("heatmap-table-mob");
                const cells = Array.from(table.querySelectorAll("tbody td:not(:first-child)"));
                //const values = cells.map(td => parseFloat(td.textContent.replace(",", ".")) || 0);
                const values = cells.map(td => parseFloat(td.textContent.replace(/\./g, '')) || 0);

                const min = {{ $minValue }}
                const max = {{ $maxValue }}

                function interpolateColor(color1, color2, factor) {
                  const c1 = parseInt(color1.slice(1), 16);
                  const c2 = parseInt(color2.slice(1), 16);
                  const r1 = (c1 >> 16) & 0xff, g1 = (c1 >> 8) & 0xff, b1 = c1 & 0xff;
                  const r2 = (c2 >> 16) & 0xff, g2 = (c2 >> 8) & 0xff, b2 = c2 & 0xff;
                  const r = Math.round(r1 + factor * (r2 - r1));
                  const g = Math.round(g1 + factor * (g2 - g1));
                  const b = Math.round(b1 + factor * (b2 - b1));
                  return `rgb(${r}, ${g}, ${b})`;
                }

                function getColor(value) {
                  const ratio = (value - min) / (max - min || 1);

                  if (ratio < 0.1) {
                    // 🔴 → 🟠
                    return interpolateColor("#d63e36", "#f7932f", ratio * 2);
                  } else {
                    // 🟠 → 🟢
                    return interpolateColor("#f7932f", "#1a9850", (ratio - 0.5) * 2);
                  }
                }

                cells.forEach(td => {
                  //const val = parseFloat(td.textContent.replace(",", ".")) || 0;
                  const val = parseFloat(td.textContent.replace(/\./g, '')) || 0;
                  if(val >0) {
                  td.style.backgroundColor = getColor(val);
                  td.style.color = "white";// val > (max - min) / 2 ? "black" : "white"; // contrast
                  } 
                  else 
                    td.style.backgroundColor = "bg-gray-100";
                });
              }

              //heatme(document.getElementById("heatmap-table-mob"));
              heatme(document.getElementById("heatmap-table"));

              </script>

       

        <hr style="margin-top: 20px; margin-bottom: 20px;">
        
        @if(!request()->has('hidechart')) 
        <div class="flex items-center justify-between mb-6">
          <h3 class="text-2xl font-bold text-gray-900">
            📊 Métricas Promedio
          </h3>
        </div>
       
        <div class="bg-white rounded-xl shadow-sm hover:shadow-lg transition-all duration-300 border border-gray-100 overflow-hidden group">
          <div class="pt-8 chart-container">
            <canvas id="chart-avg_chart" class="px-6"></canvas>
          </div>
        </div>

        <hr style="margin-top: 20px; margin-bottom: 20px;">
        @endif
    
    <!-- Rankings -->
    @if($live)
    <div class="space-y-4">
      <div class="flex items-center justify-between mb-6">
        <h3 class="text-2xl font-bold text-gray-900">
          🔴 Streams En Vivo
        </h3>
      <div class="text-sm text-gray-500 hidden sm:flex">Última actualización: {{ \Carbon\Carbon::parse($last_update)->format('H:i') }}</div>
    </div>

    <div class="bg-white rounded-xl shadow-sm hover:shadow-lg transition-all duration-300 border border-gray-100 overflow-hidden group">
      <div class="p-4 md:p-6">
        <!-- Desktop Layout -->
        <div class="hidden sm:flex items-center space-x-4">
          <!-- Channel Info -->
          <div class="flex items-center space-x-4 flex-1 min-w-0">
            <a href="{{ route('channel', $live->channel_id) }}">
            <img src="{{ $live->thumb }}" alt="{{ $live->channel_name }}" class="w-16 h-16 rounded-full object-cover border-2 border-gray-200 group-hover:border-primary transition-colors">
            </a>
            <div class="flex-1 min-w-0">
              <h3 class="font-semibold text-gray-900 truncate">{{ $live->channel_name }}                 
              @if(!request()->has('dev')) {{-- $live->live --}} {{-- $live->channel_id --}} {{-- $live->video_id --}} {{-- $live->it --}} @endif</h3>
              <p class="text-sm text-gray-600 truncate mt-1">{{ $live->video_title }}</p>
              <div class="mt-2">
                <!--span class="bg-purple-100 text-purple-800 px-2 py-1 rounded-full text-xs font-medium">
                  <a href="https://www.youtube.com/watch?v={{ $stream->video_id }}" target="_blank">Ver en YouTube</a>
                </span-->
                
                @if(sizeof($live->superchats) > 0)
                 <span class="text-sm text-gray-900 truncate">Superchats: </span>
                  @foreach($live->superchats as $superchat)  
                   <span class="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium ml-1">
                  {{  number_format($superchat->total_amount,0,",",".")  }} {{ $superchat->currency }} 
                  </span>
                  @endforeach
                @endif
              </div>
              <div class="mt-2">
                <!--span class="bg-purple-100 text-purple-800 px-2 py-1 rounded-full text-xs font-medium">Gaming</span-->
              </div>
            </div>
          </div>
                  
          <!-- Statistics -->
          <div class="flex items-center space-x-6 flex-shrink-0">
            <!-- Live Viewers -->
            <div class="text-center">
              <div class="flex items-center space-x-1 text-red-500 mb-1">
                <div class="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                <span class="text-xs font-medium uppercase tracking-wider">Live</span>
              </div>
              <div class="font-bold text-lg text-gray-900">{{ number_format($live->concurrent_viewers,0,",",".") }}</div>
              <div class="text-xs text-gray-500">conectados</div>
            </div>
            
            <!-- Likes -->
           
        

            <div class="text-center">
              <div class="text-xs text-gray-500 mb-1">&nbsp;</div>
              <div class="font-bold text-lg  {{ $live->concurrent_viewers - $live->old_viewers >= 0 ? 'text-green-600':'text-red-600' }}">
                {{ $live->concurrent_viewers - $live->old_viewers >= 0 ? "+":"" }}{{ number_format($live->concurrent_viewers - $live->old_viewers,0,",",".") }}</div>
              <div class="text-xs text-gray-500">últimos 10 min.</div>
            </div>
            
            <div class="text-center">
              <div class="text-xs text-gray-500 mb-1">👍 likes</div>
              <div class="font-bold text-lg text-gray-900">
                {{ $live->current_likes - $live->old_likes > 0 ? "+" . $live->current_likes - $live->old_likes : '-' }}
               </div>
              <div class="text-xs text-gray-500">últimos 10 min.</div>
            </div>

            <!-- Comments -->
            <!--div class="text-center">
              <div class="text-xs text-gray-500 mb-1">💬</div>
              <div class="font-bold text-lg text-gray-900">15.7K</div>
              <div class="text-xs text-gray-500">comments</div>
            </div-->
            
            <!-- Last Update -->
            @if(request()->has('hace'))
            <div class="text-center">
              <div class="text-xs text-gray-500 mb-1">🕒</div>
              <div class="font-medium text-sm text-gray-700">hace {{ intval(-1 *now()->setTimezone('GMT-3')->diffInMinutes($live->scrape_date)) }} min</div>
              <div class="text-xs text-gray-500">actualizado</div>
            </div>
            @endif 
          </div>
        </div>
        
        <!-- Mobile Layout -->
        <div class="sm:hidden">
          <div class="flex items-start space-x-3">
            <!-- Channel Thumbnail -->
            <img src="{{ $live->thumb }}" alt="{{ $live->channel_name }} {{ $live->video_title }}" class="w-12 h-12 rounded-full object-cover border-2 border-gray-200 flex-shrink-0">
            
            <!-- Content -->
            <div class="flex-1 min-w-0">
              <h3 class="font-semibold text-gray-900 text-sm leading-tight">{{ $live->channel_name }}</h3>
              <p class="text-xs text-gray-600 mt-1 line-clamp-2">{{ $live->video_title }}</p>
              
              <!-- Mobile Stats -->
              <div class="flex items-center space-x-4 mt-3">
                <div class="flex items-center space-x-1">
                  <div class="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse"></div>
                  <span class="text-xs font-medium text-red-500">{{ number_format($live->concurrent_viewers,0,",",".") }}</span>
                </div>
                <div class="flex items-center space-x-1">
                  <span class="text-xs font-medium text-gray-500">👍 {{ $live->current_likes - $live->old_likes > 0 ? "+" . $live->current_likes - $live->old_likes : '-' }}</span>
                </div>
                <!--div class="flex items-center space-x-1">
                  <span class="text-xs">👍</span>
                  <span class="text-xs font-medium text-gray-700">8.9K</span>
                </div-->
                <!--span class="bg-purple-100 text-purple-800 px-2 py-0.5 rounded-full text-xs font-medium">Gaming</span-->
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    @if(!request()->has('hidechart')) 
    <div class="bg-white rounded-xl shadow-sm hover:shadow-lg transition-all duration-300 border border-gray-100 overflow-hidden group">
      <div class="pt-8 chart-container">
        <canvas id="chart-{{ $live->video_id }}" class="px-6"></canvas>
      </div>
    </div>
    @endif

    <hr style="margin-top: 20px; margin-bottom: 20px;">

    @endif

    <!-- Rankings -->
    @if(sizeof($streams) > 0)
    <div class="space-y-4">
      <div class="flex items-center justify-between mb-6">
        <h3 class="text-2xl font-bold text-gray-900">
          📈 Streams finalizados
        </h3> 
    </div>
    @endif
          

    @foreach ($streams as $stream)
    <div id="{{ $stream->video_id }}" class="bg-white rounded-xl shadow-sm hover:shadow-lg transition-all duration-300 border border-gray-100 overflow-hidden group">
      <div class="p-4 md:p-6">
        <!-- Desktop Layout -->
        <div class="hidden sm:flex items-center space-x-4">
          <!-- Rank Badge -->
          <!--div class="flex-shrink-0">
            <div class="
            @if( $loop->index == 0 ) bg-gradient-to-r from-yellow-400 to-yellow-600 text-white  @elseif($loop->index == 1) bg-gradient-to-r from-gray-300 to-gray-400 text-gray-800 @elseif($loop->index == 2) bg-gradient-to-r from-orange-400 to-orange-600 text-white @else bg-gray-100 text-gray-700   @endif
      
            w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg shadow-md">
              {{ $loop->index + 1 }}
            </div>
          </div-->
          
          <!-- Channel Info -->
          <div class="flex items-center space-x-4 flex-1 min-w-0">
            <img src="{{ $stream->thumb }}" alt="{{ $stream->channel_name }}" class="w-16 h-16 rounded-full object-cover border-2 border-gray-200 group-hover:border-primary transition-colors">
            <div class="flex-1 min-w-0">
              <h3 class="font-semibold text-gray-900 truncate">{{ $stream->channel_name }} ({{ \Carbon\Carbon::parse($stream->start_date)->format('d/m') }})
           
              @if(request()->has('del')) 
              <a href="{{ route('video.delete', $stream->video_id) }}">  
             sss {{ $stream->video_id }}
              </a> 
              @endif
              </h3>
              <p class="text-sm text-gray-600 truncate mt-1">{{ $stream->video_title }} </p>
              <div class="mt-2">
                <!--span class="bg-purple-100 text-purple-800 px-2 py-1 rounded-full text-xs font-medium">
                  <a href="https://www.youtube.com/watch?v={{ $stream->video_id }}" target="_blank">Ver en YouTube</a>
                </span-->
                
                @if(sizeof($stream->superchats) > 0)
                 <span class="text-sm text-gray-900 truncate">Superchats: </span>
                  @foreach($stream->superchats as $superchat)  
                   <span class="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium ml-1">
                  {{  number_format($superchat->total_amount,0,",",".")  }} {{ $superchat->currency }} 
                  </span>
                  @endforeach
                @endif
              </div>
            </div>
          </div>
        
          
          <!-- Statistics -->
          <div class="flex items-center space-x-6 flex-shrink-0">
            <!-- Live Viewers -->
            <div class="text-center">
              <div class="flex items-center space-x-1 text-red-500 mb-1">
                <div class="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                <span class="text-xs font-medium uppercase tracking-wider">Live</span>
              </div>
              <div class="font-bold text-lg text-gray-900">{{ number_format($stream->max_users,0,",",".") }}</div>
              <div class="text-xs text-gray-500">max. conectados</div>
            </div>
            
            <!-- Likes -->
          
        

            <div class="text-center">
              <div class="text-xs text-gray-500 mb-1">&nbsp;</div>
              <div class="font-bold text-lg text-gray-900">
                {{ number_format($stream->concurrent_viewers,0,",",".") }}   </div>
              <div class="text-xs text-gray-500">fin programa</div>
            </div>
            
            <div class="text-center">
              <div class="text-xs text-gray-500 mb-1">👍 likes</div>
              <div class="font-bold text-lg text-gray-900">
                {{ number_format($stream->current_likes,0,",",".") }}
              </div>
              <div class="text-xs text-gray-500">total programa</div>
            </div>

            <!-- Comments -->
            <!--div class="text-center">
              <div class="text-xs text-gray-500 mb-1">💬</div>
              <div class="font-bold text-lg text-gray-900">15.7K</div>
              <div class="text-xs text-gray-500">comments</div>
            </div-->
            
            <!-- Last Update -->
            @if(request()->has('hace'))
            <div class="text-center">
              <div class="text-xs text-gray-500 mb-1">🕒</div>
              <div class="font-medium text-sm text-gray-700">hace {{ intval(-1 *now()->setTimezone('GMT-3')->diffInMinutes($stream->scrape_date)) }} min</div>
              <div class="text-xs text-gray-500">actualizado</div>
            </div>
            @endif 
          </div>
        </div>    
        <!-- Mobile Layout -->
        <div class="sm:hidden">
          <div class="flex items-start space-x-3">
            <!-- Channel Thumbnail -->
            <img src="{{ $stream->thumb }}" alt="{{ $stream->channel_name }} {{ $stream->video_title }}" class="w-12 h-12 rounded-full object-cover border-2 border-gray-200 flex-shrink-0">
            
            <!-- Content -->
            <div class="flex-1 min-w-0">
              <h3 class="font-semibold text-gray-900 text-sm leading-tight">{{ $stream->channel_name }} ({{ \Carbon\Carbon::parse($stream->start_date)->format('d/m') }})</h3>
              <p class="text-xs text-gray-600 mt-1 line-clamp-2">{{ $stream->video_title }}</p>
              
              <!-- Mobile Stats -->
              <div class="flex items-center space-x-4 mt-3">
                <div class="flex items-center space-x-1">
                  <div class="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse"></div>
                  <span class="text-xs font-medium text-red-500">{{ number_format($stream->concurrent_viewers,0,",",".") }}</span>
                </div>
                <div class="flex items-center space-x-1">
                  <span class="text-xs font-medium text-gray-500">👍 {{ $stream->current_likes  }}</span>
                </div>
                <!--div class="flex items-center space-x-1">
                  <span class="text-xs">👍</span>
                  <span class="text-xs font-medium text-gray-700">8.9K</span>
                </div-->
                <!--span class="bg-purple-100 text-purple-800 px-2 py-0.5 rounded-full text-xs font-medium">Gaming</span-->
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    @if(!request()->has('hidechart')) 
    <div class="bg-white rounded-xl shadow-sm hover:shadow-lg transition-all duration-300 border border-gray-100 overflow-hidden group">
      <div class="pt-8 chart-container">
        <canvas id="chart-{{ $stream->video_id }}" class="px-6"></canvas>
      </div>
    </div>
   

    <hr style="margin-top: 20px; margin-bottom: 20px;">
    @endif
    @endforeach

<script>
        document.addEventListener('DOMContentLoaded', function () {
            @foreach ($streams as $stream)
                // Function to initialize chart for each stream
                (function(videoId, labels, viewersData, likesData, comments_count) {
                    const ctx = document.getElementById('chart-' + videoId).getContext('2d');
                    new Chart(ctx, {
                        type: 'line',
                        data: {
                            labels: labels,
                            datasets: [
                                {
                                    label: 'Usuarios Conectados',
                                    data: viewersData,
                                    borderColor: '#4582e6ff',
                                    backgroundColor: '#4582e6ff',
                                    fill: false,
                                    yAxisID: 'y', // Left axis
                                },
                                {
                                    label: 'Likes',
                                    data: likesData,
                                    borderColor: '#f15555ff',
                                    backgroundColor: '#f15555ff',
                                    fill: false,
                                    yAxisID: 'y1', // Right axis
                                }@if($stream->data->last()->comments_count > 0),
                                {
                                    label: 'Comentarios',
                                    data: comments_count,
                                    borderColor: '#f3c806ff',
                                    backgroundColor: '#f3c806ff',
                                    fill: false,
                                    yAxisID: 'y2', // Right axis
                                }
                                @endif
                            ]
                        },
                        options: {
                            scales: {
                                x: {
                                    title: {
                                        display: true,
                                        text: 'Hora'
                                    }
                                },
                                y: {
                                    position: 'left',
                                    title: {
                                        display: true,
                                        text: 'Usuarios Conectados'
                                    },
                                    beginAtZero: true // Autoscales from 0; remove for dynamic min
                                },
                                y1: {
                                    position: 'right',
                                    title: {
                                        display: true,
                                        text: 'Likes'
                                    },
                                    grid: {
                                        drawOnChartArea: false // Avoid overlapping grids
                                    },
                                    beginAtZero: true
                                }@if($stream->data->last()->comments_count > 0),
                                y2: {
                                    position: 'right',
                                    title: {
                                        display: true,
                                        text: 'Comentarios'
                                    },
                                    grid: {
                                        drawOnChartArea: false // Avoid overlapping grids
                                    },
                                    beginAtZero: true
                                }
                                @endif
                            },
                            interaction: {
                                intersect: false // Allows tooltips across datasets
                            }
                        }
                    });
                })('{{ $stream->video_id }}', @json($stream->data->pluck('scrape_date')->toArray()), @json($stream->data->pluck('concurrent_viewers')->toArray()), @json($stream->data->pluck('likes')->toArray()), @json($stream->data->pluck('comments_count')->toArray()));
            @endforeach

            @if($live)
            (function(videoId, labels, viewersData, likesData, chatData, comments_count) {
                    const ctx = document.getElementById('chart-{{ $live->video_id }}').getContext('2d');
                    new Chart(ctx, {
                        type: 'line',
                        data: {
                            labels: labels,
                            datasets: [
                                {
                                    label: 'Usuarios Conectados',
                                    data: viewersData,
                                    borderColor: '#4582e6ff',
                                    backgroundColor: '#4582e6ff',
                                    fill: false,
                                    yAxisID: 'y', // Left axis
                                },
                                {
                                    label: 'Likes',
                                    data: likesData,
                                    borderColor: '#f15555ff',
                                    backgroundColor: '#f15555ff',
                                    fill: false,
                                    yAxisID: 'y1', // Right axis
                                }/*,
                                {
                                    label: 'Comentarios',
                                    data: chatData,
                                    borderColor: '#f3c806ff',
                                    backgroundColor: '#f3c806ff',
                                    fill: false,
                                    yAxisID: 'y1', // Right axis
                                }*/,
                                {
                                    label: 'Comentarios',
                                    data: comments_count,
                                    borderColor: '#f3c806ff',
                                    backgroundColor: '#f3c806ff',
                                    fill: false,
                                    yAxisID: 'y2', // Right axis
                                }
                            ]
                        },
                        options: {
                            scales: {
                                x: {
                                    title: {
                                        display: true,
                                        text: 'Hora'
                                    }
                                },
                                y: {
                                    position: 'left',
                                    title: {
                                        display: true,
                                        text: 'Usuarios Conectados'
                                    },
                                    beginAtZero: true // Autoscales from 0; remove for dynamic min
                                },
                                y1: {
                                    position: 'right',
                                    title: {
                                        display: true,
                                        text: 'Likes'
                                    },
                                    grid: {
                                        drawOnChartArea: false // Avoid overlapping grids
                                    },
                                    beginAtZero: true
                                },
                                y2: {
                                    position: 'right',
                                    title: {
                                        display: true,
                                        text: 'Comentarios'
                                    },
                                    grid: {
                                        drawOnChartArea: false // Avoid overlapping grids
                                    },
                                    beginAtZero: true
                                }
                            },
                            interaction: {
                                intersect: false // Allows tooltips across datasets
                            }
                        }
                    });
            })('{{ $live->video_id }}', @json($live->data->pluck('scrape_date')->toArray()), @json($live->data->pluck('concurrent_viewers')->toArray()), @json($live->data->pluck('likes')->toArray()), @json($live->data->pluck('chat_count')->toArray()), @json($live->data->pluck('comments_count')->toArray()));
            @endif


            (function(videoId, labels, viewersData, likesData/*, chatData*/) {
                    const ctx = document.getElementById('chart-avg_chart').getContext('2d');
                    new Chart(ctx, {
                        type: 'line',
                        data: {
                            labels: labels,
                            datasets: [
                                {
                                    label: 'Usuarios Conectados',
                                    data: viewersData,
                                    borderColor: '#4582e6ff',
                                    backgroundColor: '#4582e6ff',
                                    fill: false,
                                    yAxisID: 'y', // Left axis
                                },
                                {
                                    label: 'Likes',
                                    data: likesData,
                                    borderColor: '#f15555ff',
                                    backgroundColor: '#f15555ff',
                                    fill: false,
                                    yAxisID: 'y1', // Right axis
                                }/*,
                                {
                                    label: 'Comments',
                                    data: chatData,
                                    borderColor: '#b92910ff',
                                    backgroundColor: 'rgba(16, 185, 129, 0.1)',
                                    fill: false,
                                    yAxisID: 'y2', // Right axis
                                }*/
                            ]
                        },
                        options: {
                            scales: {
                                x: {
                                    title: {
                                        display: true,
                                        text: 'Hora'
                                    }
                                },
                                y: {
                                    position: 'left',
                                    title: {
                                        display: true,
                                        text: 'Usuarios Conectados'
                                    },
                                    beginAtZero: true // Autoscales from 0; remove for dynamic min
                                },
                                y1: {
                                    position: 'right',
                                    title: {
                                        display: true,
                                        text: 'Likes'
                                    },
                                    grid: {
                                        drawOnChartArea: false // Avoid overlapping grids
                                    },
                                    beginAtZero: true
                                }/*,
                                y2: {
                                    position: 'right',
                                    title: {
                                        display: true,
                                        text: 'Comments'
                                    },
                                    grid: {
                                        drawOnChartArea: false // Avoid overlapping grids
                                    },
                                    beginAtZero: true
                                }*/
                            },
                            interaction: {
                                intersect: false // Allows tooltips across datasets
                            }
                        }
                    });
            })('avg_chart', @json($avg_data->pluck('scrape_date1')->toArray()), @json($avg_data->pluck('avg_viewers')->toArray()), @json($avg_data->pluck('avg_likes')->toArray()));
            
        });
    </script>

    

  

  
      </div>

      <!-- Footer Note -->
      <div class="mt-12 text-center">
        <p class="text-gray-500 text-sm">
                    Rankings actualizados cada 10 minutos con datos en tiempo real de la API de YouTube.<br>
          <a href="https://x.com/streamingargy" target="_blank" class="text-blue-500 hover:text-blue-700">@streamingargy</a>
        </p>
      </div>
    </main>

      </div>

  </div>
  </div>
</body>
</html>