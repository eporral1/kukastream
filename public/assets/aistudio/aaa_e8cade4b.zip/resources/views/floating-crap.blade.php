<!--div class="absolute inset-0 overflow-hidden pointer-events-none">
    <! -- Animated gradient orbs -- >
    <div class="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-br from-blue-400/20 to-purple-600/20 rounded-full mix-blend-multiply filter blur-xl animate-pulse"></div>
    <div class="absolute -bottom-40 -left-40 w-80 h-80 bg-gradient-to-br from-pink-400/20 to-red-600/20 rounded-full mix-blend-multiply filter blur-xl animate-pulse" style="animation-delay: 2s;"></div>
    <div class="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-gradient-to-br from-yellow-400/10 to-orange-600/10 rounded-full mix-blend-multiply filter blur-xl animate-pulse" style="animation-delay: 4s;"></div>
    
    <! -- Subtle grid pattern -- >
    <div class="absolute inset-0 bg-grid-pattern opacity-5"></div>
    
    < !-- Floating particles -- >
    <div class="absolute top-20 left-1/4 w-2 h-2 bg-blue-400/30 rounded-full animate-bounce" style="animation-delay: 1s; animation-duration: 3s;"></div>
    <div class="absolute top-40 right-1/4 w-1 h-1 bg-purple-400/40 rounded-full animate-bounce" style="animation-delay: 2s; animation-duration: 4s;"></div>
    <div class="absolute bottom-40 left-1/3 w-1.5 h-1.5 bg-pink-400/30 rounded-full animate-bounce" style="animation-delay: 3s; animation-duration: 5s;"></div>
    <div class="absolute bottom-60 right-1/3 w-1 h-1 bg-indigo-400/40 rounded-full animate-bounce" style="animation-delay: 4s; animation-duration: 3.5s;"></div>
</div-->