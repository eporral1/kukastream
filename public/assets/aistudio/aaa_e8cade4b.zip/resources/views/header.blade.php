















  <!-- Header -->
    <!--header class="bg-white shadow-sm border-b border-gray-200">
      <div class="@if(request()->has('dev')) max-w-3xl @else max-w-7xl @endif mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between items-center h-16">
          <div class="flex items-center space-x-3">
            <div class="w-10 h-10 bg-gradient-to-r from-primary to-secondary rounded-lg flex items-center justify-center">
              <img src="{{ asset('img/logo.jpg') }}">
            </div>
            <div>
              <h1 class="text-xl font-bold text-gray-900">Streaming Argy</h1>
              <p class="text-xs text-gray-500">Ranking de streamings de Argentina</p>
            </div>
          </div>
          <div class="flex items-center space-x-2 text-sm text-gray-600">
            <div class="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span>Actualizado en vivo</span>
          </div>
        </div>
      </div>
    </header-->
    <header class="bg-white shadow-sm border-b border-gray-200">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between items-center h-16">
          
          <!-- Logo + Title -->
          <div class="flex items-center space-x-3">
              <a href="{{ route('home') }}" class="">
              <div class="w-10 h-10 bg-gradient-to-r from-primary to-secondary rounded-lg flex items-center justify-center">
                <img src="https://streamingargy.thepodcastblog.com/img/logo.jpg" alt="Logo" class="rounded">
              </div>
              </a>
              <a href="{{ route('home') }}" class="">
              <div>
                <h1 class="text-xl font-bold text-gray-900">Streaming Argy</h1>
                <p class="text-xs text-gray-500 hidden sm:flex">Ranking de streamings de Argentina</p>
              </div>
              </a>
          </div>

          <!-- Right section: Menu + Live indicator -->
          <div class="flex items-center space-x-8">
            <!-- Menu -->
             <nav class="hidden md:flex items-center space-x-8">
              <a href="{{ route('home') }}" class="text-gray-700 hover:text-primary font-medium transition-colors">Home</a>
              <a href="{{ route('channels') }}" class="text-gray-700 hover:text-primary font-medium transition-colors">Canales</a>
              <!--a href="#" class="hover:text-primary">Estadísticas</a>
              <a href="#" class="hover:text-primary">Noticias</a>
              <a href="#" class="hover:text-primary">Contacto</a-->
            </nav>
            <div class="hidden md:flex items-center space-x-2 text-sm text-gray-600">
            <div class="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span>Actualizado en vivo</span>
          </div>
          
          <!-- Mobile menu button -->
          <div class="md:hidden">
            <button onclick="toggleMobileMenu()" class="inline-flex items-center justify-center p-2 rounded-md text-gray-700 hover:text-primary hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-primary transition-colors" aria-expanded="false">
              <span class="sr-only">Open main menu</span>
              <svg id="hamburger" class="h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
              </svg>
            </button>
          </div>

          </div>

        </div>
          <!-- Mobile menu -->
        <div id="mobile-menu" class="md:hidden absolute top-16 left-0 right-0 bg-white border-b border-gray-200 shadow-lg hidden">
          <div class="px-2 pt-2 pb-3 space-y-1">
            <a href="{{ route('home') }}" class="block px-3 py-2 text-gray-700 hover:text-primary hover:bg-gray-50 rounded-md font-medium transition-colors">Home</a>
            <a href="{{ route('channels') }}" class="block px-3 py-2 text-gray-700 hover:text-primary hover:bg-gray-50 rounded-md font-medium transition-colors">Canales</a>
            <!--a href="#" class="block px-3 py-2 text-gray-700 hover:text-primary hover:bg-gray-50 rounded-md font-medium transition-colors">Categories</a>
            <a href="#" class="block px-3 py-2 text-gray-700 hover:text-primary hover:bg-gray-50 rounded-md font-medium transition-colors">Analytics</a>
            <a href="#" class="block px-3 py-2 text-gray-700 hover:text-primary hover:bg-gray-50 rounded-md font-medium transition-colors">About</a-->
            <div class="border-t border-gray-200 pt-3 mt-3">
              <div class="flex items-center space-x-2 px-3 py-2 text-sm text-gray-600">
                <div class="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                    <span>Actualizado en vivo</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
<script>
window.toggleMobileMenu = function() {
  const mobileMenu = document.getElementById('mobile-menu');
  const hamburger = document.getElementById('hamburger');
  const isOpen = mobileMenu.classList.contains('hidden');
  
  if (isOpen) {
    mobileMenu.classList.remove('hidden');
    hamburger.innerHTML = `
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
    `;
  } else {
    mobileMenu.classList.add('hidden');
    hamburger.innerHTML = `
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
    `;
  }
};

</script>
