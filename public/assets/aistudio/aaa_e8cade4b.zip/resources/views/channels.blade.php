<!DOCTYPE html><html lang="en">
  <head>
    @if($_SERVER["REMOTE_ADDR"] != "::1")
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-DG4Y02M27H"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
      gtag('config', 'G-DG4Y02M27H');
    </script>
    @endif
    <meta charset="UTF-8">
    <link rel="icon" type="image/svg+xml" href="{{ asset('img/logo.jpg') }}">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Ranking en vivo de los streaming más vistos de Argentina">
    <meta name="keywords" content="streaming, stream, usuarios, métricas, analytics, @foreach ($streams as $stream){{ $stream->channel }}, @endforeach">
    <meta property="og:image" content="https://streamingargy.thepodcastblog.com/featured.png">
    <title>Streaming Argy</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
      tailwind.config = {
        theme: {
          extend: {
            colors: {
              primary: '#3B82F6',
              secondary: '#14B8A6',
              accent: '#F97316',
              success: '#10B981',
              warning: '#F59E0B',
              error: '#EF4444'
            }
          }
        }
      }
    </script>
    <!--script type="module" crossorigin="" src="/assets/index--SwiM7HS.js"></script-->
    <link rel="stylesheet" crossorigin="" href="{{ asset('css/index-Ct_hi4gO2.css') }}">
  <!--script async="" src="https://bolt.new/badge.js?s=744581f4-b1b2-4930-977d-952c6b953a15"></script>
  <style>*, ::before, ::after{--tw-border-spacing-x:0;--tw-border-spacing-y:0;--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness:proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:rgb(59 130 246 / 0.5);--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000;--tw-shadow-colored:0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }::backdrop{--tw-border-spacing-x:0;--tw-border-spacing-y:0;--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness:proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:rgb(59 130 246 / 0.5);--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000;--tw-shadow-colored:0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }/* ! tailwindcss v3.4.17 | MIT License | https://tailwindcss.com */*,::after,::before{box-sizing:border-box;border-width:0;border-style:solid;border-color:#e5e7eb}::after,::before{--tw-content:''}:host,html{line-height:1.5;-webkit-text-size-adjust:100%;-moz-tab-size:4;tab-size:4;font-family:ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";font-feature-settings:normal;font-variation-settings:normal;-webkit-tap-highlight-color:transparent}body{margin:0;line-height:inherit}hr{height:0;color:inherit;border-top-width:1px}abbr:where([title]){-webkit-text-decoration:underline dotted;text-decoration:underline dotted}h1,h2,h3,h4,h5,h6{font-size:inherit;font-weight:inherit}a{color:inherit;text-decoration:inherit}b,strong{font-weight:bolder}code,kbd,pre,samp{font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;font-feature-settings:normal;font-variation-settings:normal;font-size:1em}small{font-size:80%}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}sub{bottom:-.25em}sup{top:-.5em}table{text-indent:0;border-color:inherit;border-collapse:collapse}button,input,optgroup,select,textarea{font-family:inherit;font-feature-settings:inherit;font-variation-settings:inherit;font-size:100%;font-weight:inherit;line-height:inherit;letter-spacing:inherit;color:inherit;margin:0;padding:0}button,select{text-transform:none}button,input:where([type=button]),input:where([type=reset]),input:where([type=submit]){-webkit-appearance:button;background-color:transparent;background-image:none}:-moz-focusring{outline:auto}:-moz-ui-invalid{box-shadow:none}progress{vertical-align:baseline}::-webkit-inner-spin-button,::-webkit-outer-spin-button{height:auto}[type=search]{-webkit-appearance:textfield;outline-offset:-2px}::-webkit-search-decoration{-webkit-appearance:none}::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}summary{display:list-item}blockquote,dd,dl,figure,h1,h2,h3,h4,h5,h6,hr,p,pre{margin:0}fieldset{margin:0;padding:0}legend{padding:0}menu,ol,ul{list-style:none;margin:0;padding:0}dialog{padding:0}textarea{resize:vertical}input::placeholder,textarea::placeholder{opacity:1;color:#9ca3af}[role=button],button{cursor:pointer}:disabled{cursor:default}audio,canvas,embed,iframe,img,object,svg,video{display:block;vertical-align:middle}img,video{max-width:100%;height:auto}[hidden]:where(:not([hidden=until-found])){display:none}.mx-auto{margin-left:auto;margin-right:auto}.mb-1{margin-bottom:0.25rem}.mb-2{margin-bottom:0.5rem}.mb-4{margin-bottom:1rem}.mb-6{margin-bottom:1.5rem}.mb-8{margin-bottom:2rem}.mt-1{margin-top:0.25rem}.mt-12{margin-top:3rem}.mt-2{margin-top:0.5rem}.flex{display:flex}.grid{display:grid}.h-10{height:2.5rem}.h-12{height:3rem}.h-16{height:4rem}.h-2{height:0.5rem}.min-h-screen{min-height:100vh}.w-10{width:2.5rem}.w-12{width:3rem}.w-16{width:4rem}.w-2{width:0.5rem}.min-w-0{min-width:0px}.max-w-2xl{max-width:42rem}.max-w-7xl{max-width:80rem}.flex-1{flex:1 1 0%}.flex-shrink-0{flex-shrink:0}@keyframes pulse{50%{opacity:.5}}.animate-pulse{animation:pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite}.grid-cols-1{grid-template-columns:repeat(1, minmax(0, 1fr))}.flex-col{flex-direction:column}.flex-wrap{flex-wrap:wrap}.items-center{align-items:center}.justify-center{justify-content:center}.justify-between{justify-content:space-between}.gap-2{gap:0.5rem}.gap-4{gap:1rem}.gap-6{gap:1.5rem}.space-x-1 > :not([hidden]) ~ :not([hidden]){--tw-space-x-reverse:0;margin-right:calc(0.25rem * var(--tw-space-x-reverse));margin-left:calc(0.25rem * calc(1 - var(--tw-space-x-reverse)))}.space-x-2 > :not([hidden]) ~ :not([hidden]){--tw-space-x-reverse:0;margin-right:calc(0.5rem * var(--tw-space-x-reverse));margin-left:calc(0.5rem * calc(1 - var(--tw-space-x-reverse)))}.space-x-3 > :not([hidden]) ~ :not([hidden]){--tw-space-x-reverse:0;margin-right:calc(0.75rem * var(--tw-space-x-reverse));margin-left:calc(0.75rem * calc(1 - var(--tw-space-x-reverse)))}.space-x-4 > :not([hidden]) ~ :not([hidden]){--tw-space-x-reverse:0;margin-right:calc(1rem * var(--tw-space-x-reverse));margin-left:calc(1rem * calc(1 - var(--tw-space-x-reverse)))}.space-x-6 > :not([hidden]) ~ :not([hidden]){--tw-space-x-reverse:0;margin-right:calc(1.5rem * var(--tw-space-x-reverse));margin-left:calc(1.5rem * calc(1 - var(--tw-space-x-reverse)))}.space-y-4 > :not([hidden]) ~ :not([hidden]){--tw-space-y-reverse:0;margin-top:calc(1rem * calc(1 - var(--tw-space-y-reverse)));margin-bottom:calc(1rem * var(--tw-space-y-reverse))}.overflow-hidden{overflow:hidden}.truncate{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.rounded-full{border-radius:9999px}.rounded-lg{border-radius:0.5rem}.rounded-xl{border-radius:0.75rem}.border{border-width:1px}.border-2{border-width:2px}.border-b{border-bottom-width:1px}.border-gray-100{--tw-border-opacity:1;border-color:rgb(243 244 246 / var(--tw-border-opacity, 1))}.border-gray-200{--tw-border-opacity:1;border-color:rgb(229 231 235 / var(--tw-border-opacity, 1))}.bg-gray-50{--tw-bg-opacity:1;background-color:rgb(249 250 251 / var(--tw-bg-opacity, 1))}.bg-blue-100{--tw-bg-opacity:1;background-color:rgb(219 234 254 / var(--tw-bg-opacity, 1))}.bg-gray-100{--tw-bg-opacity:1;background-color:rgb(243 244 246 / var(--tw-bg-opacity, 1))}.bg-green-100{--tw-bg-opacity:1;background-color:rgb(220 252 231 / var(--tw-bg-opacity, 1))}.bg-green-500{--tw-bg-opacity:1;background-color:rgb(34 197 94 / var(--tw-bg-opacity, 1))}.bg-indigo-100{--tw-bg-opacity:1;background-color:rgb(224 231 255 / var(--tw-bg-opacity, 1))}.bg-orange-100{--tw-bg-opacity:1;background-color:rgb(255 237 213 / var(--tw-bg-opacity, 1))}.bg-pink-100{--tw-bg-opacity:1;background-color:rgb(252 231 243 / var(--tw-bg-opacity, 1))}.bg-primary{--tw-bg-opacity:1;background-color:rgb(59 130 246 / var(--tw-bg-opacity, 1))}.bg-purple-100{--tw-bg-opacity:1;background-color:rgb(243 232 255 / var(--tw-bg-opacity, 1))}.bg-red-100{--tw-bg-opacity:1;background-color:rgb(254 226 226 / var(--tw-bg-opacity, 1))}.bg-red-500{--tw-bg-opacity:1;background-color:rgb(239 68 68 / var(--tw-bg-opacity, 1))}.bg-white{--tw-bg-opacity:1;background-color:rgb(255 255 255 / var(--tw-bg-opacity, 1))}.bg-yellow-100{--tw-bg-opacity:1;background-color:rgb(254 249 195 / var(--tw-bg-opacity, 1))}.bg-gradient-to-br{background-image:linear-gradient(to bottom right, var(--tw-gradient-stops))}.bg-gradient-to-r{background-image:linear-gradient(to right, var(--tw-gradient-stops))}.from-gray-300{--tw-gradient-from:#d1d5db var(--tw-gradient-from-position);--tw-gradient-to:rgb(209 213 219 / 0) var(--tw-gradient-to-position);--tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to)}.from-gray-50{--tw-gradient-from:#f9fafb var(--tw-gradient-from-position);--tw-gradient-to:rgb(249 250 251 / 0) var(--tw-gradient-to-position);--tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to)}.from-orange-400{--tw-gradient-from:#fb923c var(--tw-gradient-from-position);--tw-gradient-to:rgb(251 146 60 / 0) var(--tw-gradient-to-position);--tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to)}.from-primary{--tw-gradient-from:#3B82F6 var(--tw-gradient-from-position);--tw-gradient-to:rgb(59 130 246 / 0) var(--tw-gradient-to-position);--tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to)}.from-yellow-400{--tw-gradient-from:#facc15 var(--tw-gradient-from-position);--tw-gradient-to:rgb(250 204 21 / 0) var(--tw-gradient-to-position);--tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to)}.to-gray-100{--tw-gradient-to:#f3f4f6 
  var(--tw-gradient-to-position)}.to-gray-400{--tw-gradient-to:#9ca3af var(--tw-gradient-to-position)}.to-orange-600{--tw-gradient-to:#ea580c var(--tw-gradient-to-position)}.to-secondary{--tw-gradient-to:#14B8A6 var(--tw-gradient-to-position)}.to-yellow-600{--tw-gradient-to:#ca8a04 var(--tw-gradient-to-position)}.bg-clip-text{-webkit-background-clip:text;background-clip:text}.object-cover{object-fit:cover}.p-6{padding:1.5rem}.px-2{padding-left:0.5rem;padding-right:0.5rem}.px-4{padding-left:1rem;padding-right:1rem}.py-1{padding-top:0.25rem;padding-bottom:0.25rem}.py-2{padding-top:0.5rem;padding-bottom:0.5rem}.py-8{padding-top:2rem;padding-bottom:2rem}.text-center{text-align:center}.text-2xl{font-size:1.5rem;line-height:2rem}.text-3xl{font-size:1.875rem;line-height:2.25rem}.text-4xl{font-size:2.25rem;line-height:2.5rem}.text-lg{font-size:1.125rem;line-height:1.75rem}.text-sm{font-size:0.875rem;line-height:1.25rem}.text-xl{font-size:1.25rem;line-height:1.75rem}.text-xs{font-size:0.75rem;line-height:1rem}.font-bold{font-weight:700}.font-medium{font-weight:500}.font-semibold{font-weight:600}.uppercase{text-transform:uppercase}.tracking-wider{letter-spacing:0.05em}.text-accent{--tw-text-opacity:1;color:rgb(249 115 22 / var(--tw-text-opacity, 1))}.text-blue-800{--tw-text-opacity:1;color:rgb(30 64 175 / var(--tw-text-opacity, 1))}.text-gray-500{--tw-text-opacity:1;color:rgb(107 114 128 / var(--tw-text-opacity, 1))}.text-gray-600{--tw-text-opacity:1;color:rgb(75 85 99 / var(--tw-text-opacity, 1))}.text-gray-700{--tw-text-opacity:1;color:rgb(55 65 81 / var(--tw-text-opacity, 1))}.text-gray-800{--tw-text-opacity:1;color:rgb(31 41 55 / var(--tw-text-opacity, 1))}.text-gray-900{--tw-text-opacity:1;color:rgb(17 24 39 / var(--tw-text-opacity, 1))}.text-green-800{--tw-text-opacity:1;color:rgb(22 101 52 / var(--tw-text-opacity, 1))}.text-indigo-800{--tw-text-opacity:1;color:rgb(55 48 163 / var(--tw-text-opacity, 1))}.text-orange-800{--tw-text-opacity:1;color:rgb(154 52 18 / var(--tw-text-opacity, 1))}.text-pink-800{--tw-text-opacity:1;color:rgb(157 23 77 / var(--tw-text-opacity, 1))}.text-primary{--tw-text-opacity:1;color:rgb(59 130 246 / var(--tw-text-opacity, 1))}.text-purple-600{--tw-text-opacity:1;color:rgb(147 51 234 / var(--tw-text-opacity, 1))}.text-purple-800{--tw-text-opacity:1;color:rgb(107 33 168 / var(--tw-text-opacity, 1))}.text-red-500{--tw-text-opacity:1;color:rgb(239 68 68 / var(--tw-text-opacity, 1))}.text-red-800{--tw-text-opacity:1;color:rgb(153 27 27 / var(--tw-text-opacity, 1))}.text-secondary{--tw-text-opacity:1;color:rgb(20 184 166 / var(--tw-text-opacity, 1))}.text-transparent{color:transparent}.text-white{--tw-text-opacity:1;color:rgb(255 255 255 / var(--tw-text-opacity, 1))}.text-yellow-800{--tw-text-opacity:1;color:rgb(133 77 14 / var(--tw-text-opacity, 1))}.shadow-md{--tw-shadow:0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);--tw-shadow-colored:0 4px 6px -1px var(--tw-shadow-color), 0 2px 4px -2px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)}.shadow-sm{--tw-shadow:0 1px 2px 0 rgb(0 0 0 / 0.05);--tw-shadow-colored:0 1px 2px 0 var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)}.transition-all{transition-property:all;transition-timing-function:cubic-bezier(0.4, 0, 0.2, 1);transition-duration:150ms}.transition-colors{transition-property:color, background-color, border-color, fill, stroke, -webkit-text-decoration-color;transition-property:color, background-color, border-color, text-decoration-color, fill, stroke;transition-property:color, background-color, border-color, text-decoration-color, fill, stroke, -webkit-text-decoration-color;transition-timing-function:cubic-bezier(0.4, 0, 0.2, 1);transition-duration:150ms}.duration-200{transition-duration:200ms}.duration-300{transition-duration:300ms}.hover\:bg-gray-50:hover{--tw-bg-opacity:1;background-color:rgb(249 250 251 / var(--tw-bg-opacity, 1))}.hover\:shadow-lg:hover{--tw-shadow:0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);--tw-shadow-colored:0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)}.focus\:outline-none:focus{outline:2px solid transparent;outline-offset:2px}.focus\:ring-2:focus{--tw-ring-offset-shadow:var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);--tw-ring-shadow:var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);box-shadow:var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000)}.focus\:ring-primary:focus{--tw-ring-opacity:1;--tw-ring-color:rgb(59 130 246 / var(--tw-ring-opacity, 1))}.focus\:ring-offset-2:focus{--tw-ring-offset-width:2px}.group:hover .group-hover\:border-primary{--tw-border-opacity:1;border-color:rgb(59 130 246 / var(--tw-border-opacity, 1))}@media (min-width: 640px){.sm\:flex-row{flex-direction:row}.sm\:items-center{align-items:center}.sm\:justify-between{justify-content:space-between}.sm\:px-6{padding-left:1.5rem;padding-right:1.5rem}}@media (min-width: 768px){.md\:grid-cols-4{grid-template-columns:repeat(4, minmax(0, 1fr))}}@media (min-width: 1024px){.lg\:px-8{padding-left:2rem;padding-right:2rem}}
  </style-->
  </head>
  <body class="bg-gray-50">
    <div id="app">
  <div class="min-h-screen bg-gradient-to-br from-white via-gray-50 to-gray-100 relative overflow-hidden">


    @include('floating-crap')

    <div class="relative z-10">
      <!-- Header -->
      @include('header')

      <!-- Main Content -->
      <main class="@if(request()->has('dev')) max-w-3xl @else max-w-5xl @endif mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Hero Section -->
        <div class="text-center mb-8">
          <h2 class="text-4xl font-bold text-gray-900 mb-4">
            <span class="bg-gradient-to-r from-sky-500 via-sky-300 to-sky-500  bg-clip-text text-transparent">
            <a href="{{ route('home') }}" class="">Streaming Argy</a>
            </span>
          </h2>
          <p class="text-lg text-gray-600 max-w-2xl mx-auto">
            Ranking en vivo de los streamings más vistos de Argentina
          </p>
        </div>

        <!-- Filter Section -->
        <!--div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6 mb-8">
          <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h3 class="text-lg font-semibold text-gray-900 mb-1">Categorías</h3>
              <p class="text-sm text-gray-600">Seleccioná una categoría</p>
            </div>
            <div class="flex flex-wrap gap-2">
              <a href="{{ url()->current() }}"  class="@if(!request()->has('tag')) bg-primary text-white @else bg-white text-gray-700 hover:bg-gray-50 @endif border border-gray-200 px-4 py-2 rounded-lg font-medium text-sm transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2">
                  Todos
              </a>
              
              < !--a href="{{ url()->current() }}/?tag=stream" class="@if(request()->query('tag') == 'stream') bg-primary text-white @else bg-white text-gray-700 hover:bg-gray-50 @endif  border border-gray-200 px-4 py-2 rounded-lg font-medium text-sm transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2">
                  Streaming
              </a- ->
              
              <a href="{{ url()->current() }}/?tag=entretenimiento" class="@if(request()->query('tag') == 'entretenimiento') bg-primary text-white @else bg-white text-gray-700 hover:bg-gray-50 @endif border border-gray-200 px-4 py-2 rounded-lg font-medium text-sm transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2">
                  Entretenimiento
              </a>
              
              <a href="{{ url()->current() }}/?tag=noticias" class="@if(request()->query('tag') == 'noticias') bg-primary text-white @else bg-white text-gray-700 hover:bg-gray-50 @endif border border-gray-200 px-4 py-2 rounded-lg font-medium text-sm transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2">
                  Noticias
              </a>
              
              <a href="{{ url()->current() }}/?tag=radio" class="@if(request()->query('tag') == 'radio') bg-primary text-white @else bg-white text-gray-700 hover:bg-gray-50 @endif border border-gray-200 px-4 py-2 rounded-lg font-medium text-sm transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2">
                  Radio
              </a>

              <a href="{{ url()->current() }}/?tag=política" class="@if(request()->query('tag') == 'política') bg-primary text-white @else bg-white text-gray-700 hover:bg-gray-50 @endif border border-gray-200 px-4 py-2 rounded-lg font-medium text-sm transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2">
                  Política
              </a>

              <a href="{{ url()->current() }}/?tag=deportes" class="@if(request()->query('tag') == 'deportes') bg-primary text-white @else bg-white text-gray-700 hover:bg-gray-50 @endif border border-gray-200 px-4 py-2 rounded-lg font-medium text-sm transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2">
                  Deportes
              </a>    
            </div>
          </div>
        </div-->

        <!-- Rankings -->
        <div class="space-y-4">
          <div class="flex items-center justify-between mb-6">
            <h3 class="text-2xl font-bold text-gray-900">
              Canales
            </h3>
            <!--div class="text-sm text-gray-500">Última actualización: {{ \Carbon\Carbon::parse($last_update)->format('H:i') }}</div-->
          </div>

          @foreach ($streams as $stream)
          <div class="bg-white rounded-xl shadow-sm hover:shadow-lg transition-all duration-300 border border-gray-100 overflow-hidden group">
              <div class="p-4 md:p-6">
                  <!-- Desktop Layout -->
                  <div class="hidden sm:flex items-center space-x-4">
                  <!-- Rank Badge -->
                  <!--div class="flex-shrink-0">
                      <div class="
                      @if( $loop->index == 0 ) bg-gradient-to-r from-yellow-400 to-yellow-600 text-white  @elseif($loop->index == 1) bg-gradient-to-r from-gray-300 to-gray-400 text-gray-800 @elseif($loop->index == 2) bg-gradient-to-r from-orange-400 to-orange-600 text-white @else bg-gray-100 text-gray-700   @endif
              
                      w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg shadow-md">
                      {{ $loop->index + 1 }}
                      </div>
                  </div-->
                  
                  <!-- Channel Info -->
                  <div class="flex items-center space-x-4 flex-1 min-w-0">
                      <a href="{{ route('channel', $stream->channel) }}">
                      <img src="{{ $stream->thumb }}" alt="{{ $stream->channel }}" class="w-16 h-16 rounded-full object-cover border-2 border-gray-200 group-hover:border-primary transition-colors">
                      </a>
                      <div class="flex-1 min-w-0">
                      <h3 class="font-semibold text-gray-900 truncate">{{ $stream->channel_name }} 
                        ({{ $stream->subs >= 1000000 ? number_format($stream->subs/1000000,1,".",",") . "M" : number_format($stream->subs/1000,0,".",",") . "k" }})             
                      @if(!request()->has('dev')) {{-- $stream->live --}} {{-- $stream->channel_id --}} {{-- $stream->video_id --}} {{-- $stream->it --}} @endif</h3>
                      <p class="text-sm text-gray-600 truncate mt-1">{{ $stream->description }}</p>
                      <div class="mt-2">
                          <span class="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium">
                            <a href="https://youtube.com/{{ $stream->channel }}" target="_blank">{{ $stream->channel }}</a>
                          </span>
                          &nbsp;
                          <span class="bg-purple-100 text-purple-800 px-2 py-1 rounded-full text-xs font-medium">
                            <a href="{{ route('channel', $stream->channel) }}">Métricas</a>
                          </span>
                      </div>
                      </div>
                  </div>
                  
                  
                  <!-- Statistics -->
                  <div class="flex items-center space-x-6 flex-shrink-0">
                      <!-- Live Viewers -->
                      <div class="text-center">
                      <div class="flex items-center space-x-1 text-red-500 mb-1">
                          <div class="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                          <span class="text-xs font-medium uppercase tracking-wider">Live</span>
                      </div>
                      <div class="font-bold text-lg text-gray-900">{{ number_format($stream->avg_viewers,0,",",".") }}</div>
                      <div class="text-xs text-gray-500">promedio</div>
                      </div>
                      
                      <!-- Likes -->

                      
                      <div class="text-center">
                      <div class="text-xs text-gray-500 mb-1">👍 likes</div>
                      <div class="font-bold text-lg text-gray-900">
                      {{ number_format($stream->avg_likes,0,",",".") }}
                      </div>
                      <div class="text-xs text-gray-500">por hora</div>
                      </div>

                      <!-- Comments -->
                      <!--div class="text-center">
                      <div class="text-xs text-gray-500 mb-1">💬</div>
                      <div class="font-bold text-lg text-gray-900">15.7K</div>
                      <div class="text-xs text-gray-500">comments</div>
                      </div-->
                      
                      <!-- Last Update -->
                      @if(request()->has('hace'))
                      <div class="text-center">
                      <div class="text-xs text-gray-500 mb-1">🕒</div>
                      <div class="font-medium text-sm text-gray-700">hace {{ intval(-1 *now()->setTimezone('GMT-3')->diffInMinutes($stream->scrape_date)) }} min</div>
                      <div class="text-xs text-gray-500">actualizado</div>
                      </div>
                      @endif 
                  </div>
                  </div>
                  
                  <!-- Mobile Layout -->
                  <div class="sm:hidden">
                  <div class="flex items-start space-x-3">
                      <!-- Channel Thumbnail -->
                      <img src="{{ $stream->thumb }}" alt="{{ $stream->channel }}" class="w-12 h-12 rounded-full object-cover border-2 border-gray-200 flex-shrink-0">
                      
                      <!-- Content -->
                      <div class="flex-1 min-w-0">
                      <h3 class="font-semibold text-gray-900 text-sm leading-tight">{{ $stream->channel_name }}</h3>
                      <p class="text-xs text-gray-600 mt-1 line-clamp-2">{{ $stream->description }}</p>
                      
                      <!-- Mobile Stats -->
                      <div class="flex items-center space-x-4 mt-3">
                          <div class="flex items-center space-x-1">
                          <div class="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse"></div>
                          <span class="text-xs font-medium text-red-500">{{ number_format($stream->avg_viewers,0,",",".") }}</span>
                          </div>
                          <div class="flex items-center space-x-1">
                          <span class="text-xs font-medium text-gray-500">👍 {{ number_format($stream->avg_likes,0,",",".") }}</span>
                          </div>
                          <!--div class="flex items-center space-x-1">
                          <span class="text-xs">👍</span>
                          <span class="text-xs font-medium text-gray-700">8.9K</span>
                          </div-->
                          <!--span class="bg-purple-100 text-purple-800 px-2 py-0.5 rounded-full text-xs font-medium">
                            Métricas
                          </span-->
                      </div>
                      </div>
                  </div>
                  </div>
              </div>
          </div>
          @endforeach
        </div>

        <!-- Footer Note -->
        <div class="mt-12 text-center">
          <p class="text-gray-500 text-sm">
                      Rankings actualizados cada 10 minutos con datos en tiempo real de la API de YouTube.<br>
            <a href="https://x.com/streamingargy" target="_blank" class="text-blue-500 hover:text-blue-700">@streamingargy</a>
          </p>
        </div>

      </main>

    </div>


  </div>
  </div>
</body>
</html>