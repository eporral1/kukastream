<!DOCTYPE html><html lang="en">
  <head>
    @if($_SERVER["REMOTE_ADDR"] != "::1")
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-DG4Y02M27H"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
      gtag('config', 'G-DG4Y02M27H');
    </script>
    @endif
    <meta charset="UTF-8">
    <link rel="icon" type="image/svg+xml" href="{{ asset('img/logo.jpg') }}">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Ranking en vivo de los streaming más vistos de Argentina">
    <meta name="keywords" content="streaming, stream, usuarios, métricas, analytics, @foreach ($streams as $stream){{ $stream->channel_name }}, @endforeach">
    <title>Streaming Argy</title>
    <meta property="og:title" content="Streaming Argy - Métricas en tiempo real">
    <meta property="og:description" content="Ranking en vivo de los streaming más vistos de Argentina">
    <meta property="og:image" content="https://streamingargy.thepodcastblog.com/featured.png">
    <meta property="og:url" content="https://streamingargy.thepodcastblog.com">
    <meta property="og:type" content="website">
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
      tailwind.config = {
        theme: {
          extend: {
            colors: {
              primary: '#3B82F6',
              secondary: '#14B8A6',
              accent: '#F97316',
              success: '#10B981',
              warning: '#F59E0B',
              error: '#EF4444'
            }
          }
        }
      }
    </script>
    <!--script type="module" crossorigin="" src="/assets/index--SwiM7HS.js"></script-->
    <link rel="stylesheet" crossorigin="" href="{{ asset('css/index-Ct_hi4gO2.css') }}">
  </head>
  <body class="bg-gray-50">
    <div id="app">
  <div class="min-h-screen bg-gradient-to-br from-white via-gray-50 to-gray-100 relative overflow-hidden">
   <!--  bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50  -->
    @include('floating-crap')

    <div class="relative z-10">

    @include('header')


    <!-- Main Content -->
    <main class="@if(request()->has('dev')) max-w-xl @else max-w-5xl @endif mx-auto px-4 sm:px-6 lg:px-8 py-8">

    <!-- NEW HERO --> 
    <div class="relative px-6 py-16 sm:px-12 sm:py-20 text-center mb-10">
        <!-- Live Indicator -->
        <div class="inline-flex items-center space-x-2 bg-red-500 text-white px-4 py-2 rounded-full text-sm font-medium mb-6 shadow-lg">
          <div class="w-2 h-2 bg-white rounded-full animate-pulse"></div>
          <span class="uppercase tracking-wider">En Vivo</span>
        </div>
        
        <!-- Main Title -->
        <h2 class="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 mb-6 leading-tight">
       Publicidad optimizada con <br class="hidden sm:block"> 
          <span class="bg-gradient-to-r from-primary via-purple-600 to-secondary bg-clip-text text-transparent">
           audiencia en tiempo real 
          </span> 
          <br class="hidden sm:block">
          
        </h2>        
        <!-- Subtitle -->
        <p class="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto mb-8 leading-relaxed">
          Accedé a datos precisos de los streams más relevantes de Argentina y decidí con información dónde invertir tu presupuesto.
        </p>
        
        <!-- Feature Pills -->
        <div class="flex flex-wrap justify-center gap-3 mb-8">
          <div class="inline-flex items-center space-x-2 bg-white/80 backdrop-blur-sm border border-gray-200 px-4 py-2 rounded-full text-sm font-medium text-gray-700 shadow-sm">
            <span class="text-green-500">📊</span>
            <span>Decisiones más precisas</span>
          </div>
          <div class="inline-flex items-center space-x-2 bg-white/80 backdrop-blur-sm border border-gray-200 px-4 py-2 rounded-full text-sm font-medium text-gray-700 shadow-sm">
            <span class="text-blue-500">🎯</span>
            <span>Nuevas Oportunidades</span>
          </div>
          <div class="inline-flex items-center space-x-2 bg-white/80 backdrop-blur-sm border border-gray-200 px-4 py-2 rounded-full text-sm font-medium text-gray-700 shadow-sm">
            <span class="text-purple-500">⚡</span>
            <span>Monitoreo continuo</span>
          </div>
        </div>
        
        <!-- CTA Buttons -->
        <div class="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <a href="#live" class="inline-flex items-center space-x-2 bg-gradient-to-r from-primary to-secondary text-white px-8 py-4 rounded-xl font-semibold text-lg shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300 group">
            <span>🚀</span>
            <span>Top Streamings</span>
            <svg class="w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7l5 5m0 0l-5 5m5-5H6"></path>
            </svg>
          </a>
          <a href="{{ route('channels') }}" class="inline-flex items-center space-x-2 bg-white/90 backdrop-blur-sm text-gray-700 px-8 py-4 rounded-xl font-semibold text-lg border border-gray-200 shadow-md hover:shadow-lg hover:bg-white transition-all duration-300">
            <span>📈</span>
            <span>Métricas por canal</span>
          </a>
        </div>
    </div>

    <!-- Stats Overview -->
    <!--div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
      <div class="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <div class="text-center">
          <div class="text-3xl font-bold text-primary mb-2">172.8K</div>
          <div class="text-gray-600">Total Live Viewers</div>
        </div>
      </div>
      <div class="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <div class="text-center">
          <div class="text-3xl font-bold text-secondary mb-2">8</div>
          <div class="text-gray-600">Active Streams</div>
        </div>
      </div>
      <div class="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <div class="text-center">
          <div class="text-3xl font-bold text-accent mb-2">42.1K</div>
          <div class="text-gray-600">Total Likes</div>
        </div>
      </div>
      <div class="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <div class="text-center">
          <div class="text-3xl font-bold text-purple-600 mb-2">39.6K</div>
          <div class="text-gray-600">Total Comments</div>
        </div>
      </div>
    </div-->
    <!-- END NEW HERO -->

      <!-- Hero Section -->
      <!--div class="text-center mb-8">
        <h2 class="text-4xl font-bold text-gray-900 mb-4">
          <span class="bg-gradient-to-r from-sky-500 via-sky-300 to-sky-500  bg-clip-text text-transparent">Streaming Argy</span>
        </h2>
        <p class="text-lg text-gray-600 max-w-2xl mx-auto">
          Ranking en vivo de los streamings más vistos de Argentina
        </p>
      </div-->

      <!-- Stats Overview -->
      <!--div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div class="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div class="text-center">
            <div class="text-3xl font-bold text-primary mb-2">172.8K</div>
            <div class="text-gray-600">Total Live Viewers</div>
          </div>
        </div>
        <div class="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div class="text-center">
            <div class="text-3xl font-bold text-secondary mb-2">8</div>
            <div class="text-gray-600">Active Streams</div>
          </div>
        </div>
        <div class="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div class="text-center">
            <div class="text-3xl font-bold text-accent mb-2">42.1K</div>
            <div class="text-gray-600">Total Likes</div>
          </div>
        </div>
        <div class="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div class="text-center">
            <div class="text-3xl font-bold text-purple-600 mb-2">39.6K</div>
            <div class="text-gray-600">Total Comments</div>
          </div>
        </div>
      </div-->
      <div id="categorias" style="height: 20px;"></div>
      <!-- Filter Section -->
       <!-- start
      <div  class="bg-white rounded-xl shadow-sm border border-gray-100 p-6 mb-8">
        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h3 class="text-lg font-semibold text-gray-900 mb-1">Categorías</h3>
            <p class="text-sm text-gray-600">Seleccioná una categoría</p>
          </div>
          <div class="flex flex-wrap gap-2">
            
      <a href="{{ url()->current() }}/?tag=all#categorias"  class="@if(request()->query('tag') == 'all') bg-primary text-white @else bg-white text-gray-700 hover:bg-gray-50 @endif border border-gray-200 px-4 py-2 rounded-lg font-medium text-sm transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2">
        Todos
      </a>
    
      <a href="{{ url()->current() }}#categorias" class="@if(!request()->has('tag')) bg-primary text-white @else bg-white text-gray-700 hover:bg-gray-50 @endif  border border-gray-200 px-4 py-2 rounded-lg font-medium text-sm transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2">
        Streaming
      </a>

      <a href="{{ url()->current() }}/?tag=tv#categorias" class="@if(request()->query('tag') == 'tv') bg-primary text-white @else bg-white text-gray-700 hover:bg-gray-50 @endif  border border-gray-200 px-4 py-2 rounded-lg font-medium text-sm transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2">
        TV
      </a>
    
      <a href="{{ url()->current() }}/?tag=entretenimiento#categorias" class="@if(request()->query('tag') == 'entretenimiento') bg-primary text-white @else bg-white text-gray-700 hover:bg-gray-50 @endif border border-gray-200 px-4 py-2 rounded-lg font-medium text-sm transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2">
        Entretenimiento
      </a>
     
      < !--a href="{{ url()->current() }}/?tag=noticias#categorias" class="@if(request()->query('tag') == 'noticias') bg-primary text-white @else bg-white text-gray-700 hover:bg-gray-50 @endif border border-gray-200 px-4 py-2 rounded-lg font-medium text-sm transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2">
        Noticias
      </a-- >
    
      <a href="{{ url()->current() }}/?tag=radio#categorias" class="@if(request()->query('tag') == 'radio') bg-primary text-white @else bg-white text-gray-700 hover:bg-gray-50 @endif border border-gray-200 px-4 py-2 rounded-lg font-medium text-sm transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2">
        Radio
      </a>

      <a href="{{ url()->current() }}/?tag=política#categorias" class="@if(request()->query('tag') == 'política') bg-primary text-white @else bg-white text-gray-700 hover:bg-gray-50 @endif border border-gray-200 px-4 py-2 rounded-lg font-medium text-sm transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2">
        Política
      </a>

      <a href="{{ url()->current() }}/?tag=deportes#categorias" class="@if(request()->query('tag') == 'deportes') bg-primary text-white @else bg-white text-gray-700 hover:bg-gray-50 @endif border border-gray-200 px-4 py-2 rounded-lg font-medium text-sm transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2">
        Deportes
      </a>    
          </div>
        </div>
      </div>
    end -->

      <!-- Rankings -->
       <!-- start -->
      <div class="space-y-4" id="live">
        <div class="flex items-center justify-between mb-6">
          <h3 class="text-2xl font-bold text-gray-900">
            Ranking En Vivo 
          </h3>
          <div class="text-sm text-gray-500">Última actualización: {{ \Carbon\Carbon::parse($last_update)->format('H:i') }}</div>
        </div>
        
    

  
    @foreach ($streams as $stream)


        <div id="{{ $stream->video_id }}" class="bg-white rounded-xl shadow-sm hover:shadow-lg transition-all duration-300 border border-gray-100 overflow-hidden group">
      <div class="p-4 md:p-6">
        <!-- Desktop Layout -->
        <div class="hidden sm:flex items-center space-x-4">
          <!-- Rank Badge -->
          <div class="flex-shrink-0">
            <div class="
            @if( $loop->index == 0 ) bg-gradient-to-r from-yellow-400 to-yellow-600 text-white  @elseif($loop->index == 1) bg-gradient-to-r from-gray-300 to-gray-400 text-gray-800 @elseif($loop->index == 2) bg-gradient-to-r from-orange-400 to-orange-600 text-white @else bg-gray-100 text-gray-700   @endif
      
            w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg shadow-md">
              {{ $loop->index + 1 }}
            </div>
          </div>
          
          <!-- Channel Info -->
          <div class="flex items-center space-x-4 flex-1 min-w-0">
            <a href="{{ route('channel', $stream->channel) }}">
            <img src="{{ $stream->thumb }}" alt="{{ $stream->channel_name }}" class="w-16 h-16 rounded-full object-cover border-2 border-gray-200 group-hover:border-primary transition-colors">
            </a>
            <div class="flex-1 min-w-0">
              <h3 class="font-semibold text-gray-900 truncate">{{ $stream->channel_name }}                 
              @if(!request()->has('dev')) {{-- $stream->live --}} {{-- $stream->channel_id --}} {{-- $stream->video_id --}} {{-- $stream->it --}} @endif</h3>
              <p class="text-sm text-gray-600 truncate mt-1">{{ $stream->video_title }}</p>
              <div class="mt-2">
              <span class="bg-purple-100 text-purple-800 px-2 py-0.5 rounded-full text-xs font-medium">
                <a href="{{ route('channel', $stream->channel) }}">Métricas</a>
              </span>
              </div>
            </div>
          </div>
         
          
          <!-- Statistics -->
          <div class="flex items-center space-x-6 flex-shrink-0">
            <!-- Live Viewers -->
            <div class="text-center">
              <div class="flex items-center space-x-1 text-red-500 mb-1">
                <div class="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                <span class="text-xs font-medium uppercase tracking-wider">Live</span>
              </div>
              <div class="font-bold text-lg text-gray-900">{{ number_format($stream->concurrent_viewers,0,",",".") }}</div>
              <div class="text-xs text-gray-500">conectados</div>
            </div>
            
            <!-- Likes -->
           
        
            @if(!request()->has('dev'))
            <div class="text-center">
              <div class="text-xs text-gray-500 mb-1">&nbsp;</div>
              <div class="font-bold text-lg  {{ $stream->concurrent_viewers - $stream->old_viewers >= 0 ? 'text-green-600':'text-red-600' }}">
                {{ $stream->concurrent_viewers - $stream->old_viewers >= 0 ? "+":"" }}{{ number_format($stream->concurrent_viewers - $stream->old_viewers,0,",",".") }}</div>
              <div class="text-xs text-gray-500">últimos 10 min.</div>
            </div>
            
            <div class="text-center">
              <div class="text-xs text-gray-500 mb-1">👍 likes</div>
              <div class="font-bold text-lg text-gray-900">
                {{ $stream->current_likes - $stream->old_likes > 0 ? "+" . $stream->current_likes - $stream->old_likes : '-' }}
               </div>
              <div class="text-xs text-gray-500">últimos 10 min.</div>
            </div>
            @endif

            <!-- Comments -->
            <!--div class="text-center">
              <div class="text-xs text-gray-500 mb-1">💬</div>
              <div class="font-bold text-lg text-gray-900">15.7K</div>
              <div class="text-xs text-gray-500">comments</div>
            </div-->
            
            <!-- Last Update -->
            @if(request()->has('hace'))
            <div class="text-center">
              <div class="text-xs text-gray-500 mb-1">🕒</div>
              <div class="font-medium text-sm text-gray-700">hace {{ intval(-1 *now()->setTimezone('GMT-3')->diffInMinutes($stream->scrape_date)) }} min</div>
              <div class="text-xs text-gray-500">actualizado</div>
            </div>
            @endif 
          </div>
        </div>
        
        <!-- Mobile Layout -->
        <div class="sm:hidden">
          <div class="flex items-start space-x-3">
            <!-- Channel Thumbnail -->
            <img src="{{ $stream->thumb }}" alt="{{ $stream->channel_name }} {{ $stream->video_title }}" class="w-12 h-12 rounded-full object-cover border-2 border-gray-200 flex-shrink-0">
            
            <!-- Content -->
            <div class="flex-1 min-w-0">
              <h3 class="font-semibold text-gray-900 text-sm leading-tight">{{ $stream->channel_name }} {{-- $stream->live --}} {{-- $stream->channel_id --}} {{-- $stream->video_id --}} {{-- $stream->it --}}</h3>
              <p class="text-xs text-gray-600 mt-1 line-clamp-2">{{ $stream->video_title }}</p>
              
              <!-- Mobile Stats -->
              <div class="flex items-center space-x-4 mt-3">
                <div class="flex items-center space-x-1">
                  <div class="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse"></div>
                  <span class="text-xs font-medium text-red-500">{{ number_format($stream->concurrent_viewers,0,",",".") }}</span>
                </div>
                <div class="flex items-center space-x-1">
                  <span class="text-xs font-medium text-gray-500">👍 {{ $stream->current_likes - $stream->old_likes > 0 ? "+" . $stream->current_likes - $stream->old_likes : '-' }}</span>
                </div>
                <!--div class="flex items-center space-x-1">
                  <span class="text-xs">👍</span>
                  <span class="text-xs font-medium text-gray-700">8.9K</span>
                </div-->
                <span class="bg-purple-100 text-purple-800 px-2 py-0.5 rounded-full text-xs font-medium">
                    <a href="{{ route('channel', $stream->channel) }}">Métricas</a>
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    @if(request()->has('dev') &&  $loop->index == 4)
    <br><br><br>
    @endif
    @endforeach
  

  
      </div>
 

    <!--  <p>
Streaming Argy muestra en tiempo real el ranking de los canales de streaming más vistos en Argentina.  
Se actualiza cada 10 minutos mediante la API de YouTube, registrando número de “conectados” y “likes” por canal.  
Aquí verás las principales categorías (Entretenimiento, Noticias, Deportes, Radio, Política).
</p>

      <section id="faq" class="faq-section">
  <h2>Preguntas frecuentes</h2>

  <div class="faq-item">
    <h3>¿Cada cuánto se actualiza el ranking?</h3>
    <p>El ranking de Streaming Argy se actualiza automáticamente cada <strong>10 minutos</strong>, mostrando siempre la cantidad más reciente de espectadores conectados en cada transmisión en vivo.</p>
  </div>

  <div class="faq-item">
    <h3>¿De dónde provienen los datos?</h3>
    <p>Todos los datos provienen de la <strong>API oficial de YouTube</strong>, lo que garantiza precisión, actualización constante y transparencia en las estadísticas que mostramos.</p>
  </div>

  <div class="faq-item">
    <h3>¿Qué significan los “conectados”?</h3>
    <p>“Conectados” representa el número de espectadores que están mirando una transmisión en vivo en tiempo real. Es el indicador principal que usamos para ordenar los canales en el ranking.</p>
  </div>

  <div class="faq-item">
    <h3>¿Qué canales se incluyen en el ranking?</h3>
    <p>Incluimos transmisiones públicas de YouTube relacionadas con <strong>Argentina</strong> que pertenecen a categorías como entretenimiento, noticias, deportes, política y radio. Solo se muestran canales activos con espectadores en vivo.</p>
  </div>

  <div class="faq-item">
    <h3>¿Por qué mi canal no aparece?</h3>
    <p>Si tu canal no aparece en el ranking, puede deberse a que la transmisión no es pública, tiene muy poca audiencia o no está etiquetada con contenido relevante para Argentina. Si cumples con estos criterios, debería aparecer automáticamente.</p>
  </div>
</section> -->


      <!-- Footer Note -->
      <div class="mt-12 text-center">
        <p class="text-gray-500 text-sm">
         <!-- Rankings actualizados cada 10 minutos con datos en tiempo real de la API de YouTube.<br>-->
          <a href="https://x.com/streamingargy" target="_blank" class="text-blue-500 hover:text-blue-700">@streamingargy</a>
        </p>
      </div>
    </main>
    </div>



  </div>
  </div>
  @if(!request()->has('dev'))
  <script>
  window.addEventListener('load', () => {
    setInterval(() => location.reload(), 60000);
  });
  </script>
  @endif
</body></html>