    <div class="bg-white rounded-xl shadow-sm hover:shadow-lg transition-all duration-300 border border-gray-100 overflow-hidden group">
      <div class="p-6">
        <div class="flex items-center space-x-4">
          <!-- Rank Badge -->
          <div class="flex-shrink-0">
            <div class="
            @if( $loop->index == 0 ) bg-gradient-to-r from-yellow-400 to-yellow-600 text-white  @elseif($loop->index == 1) bg-gradient-to-r from-gray-300 to-gray-400 text-gray-800 @elseif($loop->index == 2) bg-gradient-to-r from-orange-400 to-orange-600 text-white @else bg-gray-100 text-gray-700   @endif
      
            w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg shadow-md">
              {{ $loop->index + 1 }}
            </div>
          </div>
          
          <!-- Channel Info -->
          <div class="flex items-center space-x-4 flex-1 min-w-0">
            <img src="{{ $stream->thumb }}" alt="Music Live 24/7" class="w-16 h-16 rounded-full object-cover border-2 border-gray-200 group-hover:border-primary transition-colors">
            <div class="flex-1 min-w-0">
              <h3 class="font-semibold text-gray-900 truncate">{{ $stream->channel_name }} {{ $stream->live }} {{-- $stream->channel_id --}} {{ $stream->video_id }} {{-- $stream->it --}}</h3>
              <p class="text-sm text-gray-600 truncate mt-1">{{ $stream->video_title }}</p>
              <div class="mt-2">
                <!--span class="bg-pink-100 text-pink-800 px-2 py-1 rounded-full text-xs font-medium">Music</span-->
              </div>
            </div>
          </div>
          
          <!-- Statistics -->
          <div class="flex items-center space-x-6 flex-shrink-0">
           
            
            <!-- Likes -->
            <!--div class="text-center">
              <div class="text-xs text-gray-500 mb-1">👍</div>
              <div class="font-bold text-lg text-gray-900">
              @if($stream->type == "eternal")  
                {{-- $stream->max_likes - $stream->max_likes_yesterday --}} 
              @elseif($stream->type == "programa")  
                {{-- $stream->current_likes -  $stream->viejos_likes --}}
              @else
                {{-- $stream->current_likes --}}
               @endif
              </div>
              <div class="text-xs text-gray-500">
                
                @if($stream->type == "eternal")  
                  likes del día
                @elseif($stream->type == "programa")  
                  likes programa{{-- $stream->viejos_likes --}}
                @else
                  likes canal
                @endif
              </div>
            </div-->

            <!-- Live Viewers -->
            <div class="text-center">
              <div class="flex items-center space-x-1 text-red-500 mb-1">
                <div class="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                <span class="text-xs font-medium uppercase tracking-wider">Live</span>
              </div>
              <div class="font-bold text-lg text-gray-900">{{ number_format($stream->concurrent_viewers,0,",",".") }}</div>
              <div class="text-xs text-gray-500">conectados</div>
            </div>
            
            <!-- Comments -->
            <!--div class="text-center">
              <div class="text-xs text-gray-500 mb-1">💬</div>
              <div class="font-bold text-lg text-gray-900">8.9K</div>
              <div class="text-xs text-gray-500">comments</div>
            </div-->
            
            <!-- Last Update -->
            <div class="text-center">
              <div class="text-xs text-gray-500 mb-1">🕒</div>
              <div class="font-medium text-sm text-gray-700">hace {{ intval(-1 *now()->setTimezone('GMT-3')->diffInMinutes($stream->scrape_date)) }} min</div>
              <div class="text-xs text-gray-500">actualizado</div>
            </div>
          </div>
        </div>
      </div>
    </div>