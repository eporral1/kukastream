<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use ConsoleTVs\Charts\Classes\Chartjs\Chart;
use LarapexCharts\LineChart;


// create index idx_minute_scrape_date on minute (scrape_date);

/* SELECT 
    channel_name, EXTRACT(HOUR FROM scrape_date) AS hour,
    max(concurrent_viewers)::int
FROM public.minute
GROUP BY channel_name, EXTRACT(HOUR FROM scrape_date)
ORDER BY channel_name, hour;
*/

Route::get('/', function (Request $request) {

    if(!$request->input("tag"))
        $tags = "stream";
    else 
        if($request->input("tag") == "all")
            $tags = "";
    else
        $tags = $request->input("tag");

    $streams = DB::select("select * from public.live l, channels c  where l.live='live' and l.concurrent_viewers > 0 and l.channel_id = c.channel_id and c.tags like '%" . $tags . "%' order by l.concurrent_viewers desc limit 10");

    $last_update =collect($streams)->max('scrape_date'); 
    if($request->has('dev')) {
        echo "📈 Usuarios conectados en vivo " . \Carbon\Carbon::parse($last_update)->format('H:i') . "<br><br>";
        $i = 0;
        $medals = ["🥇","🥈", "🥉","4️⃣","5️⃣"];
        foreach ($streams as $row) {
            if($i < 5)
                echo $medals[$i] . " ". $row->twitter . " - " . number_format($row->concurrent_viewers,0,",",".") . "<br>";  
            $i++;
        }
 
        echo "<br>Ranking en vivo ➡️ https://shorturl.at/wytVL<br><br>#live #rating #tv #streaming #argentina";
    }

    return view('home')->with('streams', $streams)->with('last_update', $last_update);

})->name('home');

Route::get('/channels', function (Request $request) {

    $tags = $request->input("tag");
    $streams = DB::select("SELECT c.channel,c.channel_name, c.description, c.subs, c.channel_id, c.thumb, avg(l.concurrent_viewers) avg_viewers, AVG((l.current_likes - l.old_likes)*6) avg_likes  from public.live l, channels c  where  l.scrape_date >= NOW() - INTERVAL '30 days' and l.concurrent_viewers > 0 and l.channel_id = c.channel_id GROUP BY c.channel,c.channel_name, c.description, c.subs, c.channel_id, c.thumb order by avg_viewers DESC");

    $last_update =collect($streams)->max('scrape_date'); 
    if($request->has('dev')) {
        echo "#StreamingArgy<br>Usuarios conectados en vivo " . \Carbon\Carbon::parse($last_update)->format('H:i') . "<br><br>";
        $i = 0;
        $medals = ["🥇","🥈", "🥉","4️⃣","5️⃣"];
        foreach ($streams as $row) {
            if($i < 5)
                echo $medals[$i] . " ";
            //if($i < 10)
            //    echo $row->twitter . " - " . number_format($row->concurrent_viewers,0,",",".") . "<br>";  
            $i++;
        }
        echo "<br>#live #rating #tv #streaming #argentina<br>Ranking en vivo: https://shorturl.at/wytVL";
    }

    return view('channels')->with('streams', $streams)->with('last_update', $last_update);
})->name('channels');

Route::get('/channel/{channel}', function (Request $request, $channel_id) {

    if(str_contains($channel_id, '@')) {
        $channel_id = DB::select("SELECT channel_id FROM channels WHERE channel = '" . $channel_id . "'")[0]->channel_id;
    }
    
    $tags = $request->input("tag");
    $q = "select * from public.live l, channels c  where c.channel_id ='" . $channel_id . "' and l.live='live' and l.concurrent_viewers > 0 and l.channel_id = c.channel_id and c.tags like '%" . $tags . "%' order by l.concurrent_viewers desc";
    //echo $q;
    $live =  DB::select($q);
    $last_update = "";
    if(sizeof($live)) {
        $live = DB::select($q)[0];
        $live->max_users = DB::select("SELECT MAX(concurrent_viewers) as max_users FROM minute WHERE video_id = '" . $live->video_id . "'")[0]->max_users;
        $live->max_likes = DB::select("SELECT MAX(likes) as max_likes FROM minute WHERE video_id = '" . $live->video_id . "'")[0]->max_likes;
        
        // $chart = new Chart; 
        $q = "SELECT to_char(scrape_date, 'HH24:MI') AS scrape_date, concurrent_viewers, likes, chat_count, authors_count, comments_count FROM minute WHERE video_id = '" .  $live->video_id . "' AND DATE(scrape_date) = '" . substr($live->scrape_date, 0, 10) . "' ORDER BY scrape_date";
        $live->data = collect(DB::select($q));
        $last_update =collect($live->data)->max('scrape_date'); 
        $live->superchats = DB::select("SELECT currency, sum(amount) total_amount FROM superchats WHERE video_id = '" . $live->video_id . "' GROUP BY currency");
        echo "SELECT currency, sum(amount) total_amount FROM superchats WHERE video_id = '" . $live->video_id . "' GROUP BY currency";      
    }
    else
    $live = null;

   //  var_dump($live);

    $q = "select * from public.live l, public.channels c where l.live<>'live' and l.channel_id = c.channel_id and c.channel_id ='" . $channel_id . "' order by l.scrape_date desc, l.video_id limit 5";// 
    
    // $q = "SELECT DISTINCT m.video_id, m.video_title,m.channel_name, * from public.minute m, public.channels c where m.scrape_date::DATE = CURRENT_DATE and m.channel_id = c.channel_id and c.channel_id ='" . $channel_id . "'"; 
    // echo $q;
    $streams = DB::select($q);
    $charts = [];

    foreach ($streams as $row) {
        $row->max_users = DB::select("SELECT MAX(concurrent_viewers) as max_users FROM minute WHERE video_id = '" . $row->video_id . "'")[0]->max_users;
        $row->max_likes = DB::select("SELECT MAX(likes) as max_likes FROM minute WHERE video_id = '" . $row->video_id . "'")[0]->max_likes;
        $row->superchats = DB::select("SELECT currency, sum(amount) total_amount FROM superchats WHERE video_id = '" . $row->video_id . "' GROUP BY currency");
        
        // $chart = new Chart; 
        $q = "SELECT to_char(scrape_date, 'HH24:MI') AS scrape_date, concurrent_viewers, likes, comments_count FROM minute WHERE video_id = '" .  $row->video_id . "' AND DATE(scrape_date) = '" . substr($row->scrape_date, 0, 10) . "' ORDER BY scrape_date";
        //echo $q;
        $row->data = collect(DB::select($q));
    }

    //var_dump($streams);

    //$q_avg = "SELECT to_char(scrape_date, 'HH24:MI') AS scrape_date1, AVG(concurrent_viewers) as avg_viewers, AVG(likes) AS avg_likes FROM minute WHERE channel_id = 'UCnZidingmuqNkaT9Wm64Xxg' GROUP BY scrape_date1 ORDER BY scrape_date1";
    $q_avg = "SELECT scrape_date1, AVG(avg_viewers) AS avg_viewers, AVG(avg_likes) AS avg_likes
    FROM (
    SELECT 
        to_char(
            date_trunc('hour', scrape_date) + 
            interval '10 minute' * floor(extract(minute from scrape_date)::int / 10),
            'HH24:MI'
        ) AS scrape_date1,
        AVG(concurrent_viewers) AS avg_viewers,
        AVG(likes) AS avg_likes
    FROM minute
    WHERE channel_id = '".  $channel_id . "' and scrape_date >= NOW() - INTERVAL '30 days' 
    GROUP BY 
        date_trunc('hour', scrape_date) + 
        interval '10 minute' * floor(extract(minute from scrape_date)::int / 10)
    ORDER BY scrape_date1
    )
    GROUP BY scrape_date1";
    
    $avg_data = collect(DB::select($q_avg));


    $q_hour_day ="
SELECT
  hour,
  AVG(CASE WHEN dow = 1 THEN concurrent_viewers END) AS mon_viewers,
  AVG(CASE WHEN dow = 1 THEN likes END) AS mon_likes,
  AVG(CASE WHEN dow = 2 THEN concurrent_viewers END) AS tue_viewers,
  AVG(CASE WHEN dow = 2 THEN likes END) AS tue_likes,
  AVG(CASE WHEN dow = 3 THEN concurrent_viewers END) AS wed_viewers,
  AVG(CASE WHEN dow = 3 THEN likes END) AS wed_likes,
  AVG(CASE WHEN dow = 4 THEN concurrent_viewers END) AS thu_viewers,
  AVG(CASE WHEN dow = 4 THEN likes END) AS thu_likes,
  AVG(CASE WHEN dow = 5 THEN concurrent_viewers END) AS fri_viewers,
  AVG(CASE WHEN dow = 5 THEN likes END) AS fri_likes,
  AVG(CASE WHEN dow = 6 THEN concurrent_viewers END) AS sat_viewers,
  AVG(CASE WHEN dow = 6 THEN likes END) AS sat_likes,
  AVG(CASE WHEN dow = 0 THEN concurrent_viewers END) AS sun_viewers,
  AVG(CASE WHEN dow = 0 THEN likes END) AS sun_likes
FROM (
  SELECT
    DATE_PART('hour', scrape_date) AS hour,
    EXTRACT(DOW FROM scrape_date) AS dow,
    concurrent_viewers,
    likes
  FROM minute  WHERE channel_id ='" .  $channel_id . "'
    AND scrape_date >= NOW() - INTERVAL '30 days'
) t
GROUP BY hour
ORDER BY hour;";
   
    $hour_day_data = collect(DB::select($q_hour_day));

    $flatValues = collect($hour_day_data)
        ->flatMap(function ($row) {
            return collect((array) $row)
                ->filter(fn($v, $k) => str_ends_with($k, '_viewers')) // ✅ only "_viewers" columns
                ->values();
        })
        ->map(fn($v) => (float) $v);

    // ✅ Min & Max across only "_viewers" columns
    $minValue = $flatValues->filter(fn($v) => $v > 0)->min();
    $maxValue = $flatValues->max();


    $q_channel = "SELECT * FROM channels WHERE channel_id = '" .  $channel_id . "'";

    $channel = DB::select($q_channel)[0];

    // var_dump($channel);

    /*if ($live) {
        $q = "select *, (created_at AT TIME ZONE 'UTC' - INTERVAL '0 hours') AS scrape_date from public.chat  where video_id ='" . $live->video_id . "' order by created_at";
        //echo $q;
        $chat =  collect(DB::select($q));
       // var_dump($chat);
    }*/

    return view('channel')->with('streams', $streams)->with('last_update', $last_update)->with('live', $live)->with('avg_data', $avg_data)->with('hour_day_data', $hour_day_data)->with('minValue', $minValue)->with('maxValue', $maxValue)->with('channel', $channel);

})->name('channel');


Route::get('/debug', function () {
    try {
        dd(app()->make('files')); // This will throw the error with a full stack trace
    } catch (\Exception $e) {
        dd($e->getMessage(), $e->getTraceAsString());
    }
});


Route::get('/test', function (Request $request) {

    $tags = $request->input("tag");
    $q = "SELECT * FROM live where start_fixed = 0";
    
    $streams = DB::select($q);
    foreach ($streams as $stream) {
        var_dump($stream);
        $q1 = "SELECT min(scrape_date) min_date FROM minute WHERE video_id = '"  . $stream->video_id . "' AND DATE(scrape_date) = '" . substr($stream->scrape_date, 0, 10) . "'" ;
        $start_date = DB::select($q1)[0]->min_date;
        echo $start_date;
        if($start_date != null)
            DB::update("update live set start_date ='" . $start_date . "', start_fixed = 1 where video_id ='" . $stream->video_id . "'");
    }

});


Route::get('/delete/{id}', function (Request $request,$id) {

    $q = "DELETE FROM live WHERE video_id = '" . $id . "'";
    DB::delete($q);

    $q = "DELETE FROM minute WHERE video_id = '" . $id . "'";
    DB::delete($q);

})->name('video.delete');

Route::get('/cache/views', function() {
   Artisan::call('config:cache');
  // Artisan::call('route:cache');
  Artisan::call('view:cache');
  return "View cache generated!";
});

Route::get('/clear/views', function() {
  
  // Limpiar cachés
  Artisan::call('view:clear');
  // Artisan::call('route:clear');
   Artisan::call('config:clear');
  // Artisan::call('cache:clear');
  return "View cache cleared!";
});